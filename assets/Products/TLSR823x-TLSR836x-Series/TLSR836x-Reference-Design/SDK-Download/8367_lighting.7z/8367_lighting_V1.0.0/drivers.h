#pragma once

#include "config.h"
#if(__TL_LIB_8231__ || (MCU_CORE_TYPE == MCU_CORE_8231))
#include "drivers/8231/driver_8231.h"
#endif
