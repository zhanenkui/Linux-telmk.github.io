

var updateFile = "bluelight\\bluelight.bin";
// var updateFile = "telink_ble\\bluelight\\bluelight-crc1.bin";
//  to test uart ota
function blt_packet_crc24 (p, n, crc){
	//crc16�� G(X) = X16 + X15 + X2 + 1

	//crc16:  x24 + x10 + x9 + x6 + x4 + x3 + x + 1 ==> 0x00065b
	//               13   14   17   19   20  22  23 ==> 0xda6000
   // static unsigned short poly[2]={0, 0xa001};              //0x8005 <==> 0xa001

	//int		poly[2]={0, 0xda6000};              //0x8005 <==> 0xa001
	for(let j = 0; j < n; ++j){
    	let ds = p[j];
    	for(let i=0; i<8; i++) {
        	let cond = (crc ^ ds ) & 1;
        	crc >>= 1;
        	if (cond) {
        		 crc ^= 0xda6000;
        	}
            ds >>= 1;
    	}
    }
    return crc;
}
function sleep(time) {				//  in ms
    var stop = new Date().getTime();
    while(new Date().getTime() < stop + time) {
        ;
    }
}


var SerialPort = require('serialport');
var port = new SerialPort('COM3', {
		baudRate: 115200
	}, function (err) {
		if (err) {
			return console.log('Error: ', err.message);
		}
	}
);

var f_random_idx = 0;
function portWrite(b){
	let crc = blt_packet_crc24(b, b.length, 0);
	let bb = Buffer.alloc(b.length + 4);
	let pos = b.length;
	b.copy(bb);
	bb.writeInt32LE(crc, pos);
	bb = bb.slice(0, pos+3);
	//  randomly add error pkt
	f_random_idx++;
	if(0 && f_random_idx % 10 == 5 && pos > 5){
		bb[6] = 3;
		console.log('Send CRC error pkt: ', bb);
	}else{
	    console.log('Send:', bb);
	}
	port.write(bb, function(err){
		if(err){
			return console.log('Error on write: ', err.message);
		}
	});
}

const fs = require('fs');
var fd_up = fs.openSync(updateFile, 'r');
if(!fd_up){
	console.log("update file open fail..");
	return;
}
const stats = fs.statSync(updateFile)
const f_size = stats.size

var f_offset = 0;
var pkt_idx = 0;
var f_done = 0;
var f_lastOffset = 0;
function portWriteFile(resend){
	if(f_done) return 0;

	if(resend){
		f_offset = f_lastOffset;
		pkt_idx --;
	}
	if(f_offset >= f_size){
		f_done = 1;
		return 0;
	}
	
	let buf = Buffer.alloc(16+3);
	let bytes = 0;
	let ret = 1;
	var bytesRead = fs.readSync(fd_up, buf, 3, 16, f_offset);
	buf[0] = 0xdd;
	buf.writeUInt16LE(pkt_idx,1);
	
	if(bytesRead < 16){
		buf.fill(0xff, bytesRead+3);
		f_done = 1;
		ret = 0;
	}
	pkt_idx ++;
	f_lastOffset = f_offset;
	f_offset += bytesRead;
	portWrite(buf);
	return ret;
}

////////////////////////////////////////////////////////////////////////////
const otaSppStart = Buffer.from([0x55]);
const otaSppEnd = Buffer.from([0xaa]);

const otaPrepare = Buffer.from([0xdd, 0x00, 0xff]);
const otaStart = Buffer.from([0xdd, 0x01, 0xff]);
const otaEnd = Buffer.from([0xdd, 0x02, 0xff]);
const otaFirwareVer = Buffer.from([0x09]);
var otaState = 0;

port.on('data', function (data) {
	let n = data.length - 3;
	if(n > 0){
		let crc = blt_packet_crc24(data, n, 0);
		let crc1 = data.readUInt16LE(n);
		let crc2 = data.readUInt8(n + 2);
		if(crc == crc2 * 65536 + crc1){
			console.log('Recv:', data);
			if(9 == data[0]){
				if(0 == otaState){
//					console.log('Version before update is ', data[1]);
				}else{
//					console.log('Version after update is ', data[1]);
				}
			}else if(0 == data[0]){					//  ack
				if(0 == otaState){
					portWrite(otaPrepare);
					otaState = 0xff00;
				}else if(0xff00 == otaState){			// to start
					portWrite(otaStart);
					otaState = 0xff01;
				}else if(0xff01 == otaState){	// started
					if(f_done || f_offset >= f_size){
						portWrite(otaEnd);
						otaState = 0xff02;
					}else{
						portWriteFile(0);
					}
				}else if(0xff02 == otaState){
					process.exit();
				}
			}else if(0x0a == data[0]){
				if(0 == data[1]){
					console.log('File update done');
				}else if(0xfd == data[1]){
					console.log('CRC error, Resend');
					portWriteFile(1);
				}else{
					console.log('File update fail');
					process.exit();
				}
			}
		}else{
			console.log('Recv Wrong crc:', data);
		}
	}else{
		if(0xff02 == otaState){
			portWrite(otaSppEnd);
		}else{
			console.log('Recv wrong len:', data);
		}
	}
});

portWrite(otaSppStart);


