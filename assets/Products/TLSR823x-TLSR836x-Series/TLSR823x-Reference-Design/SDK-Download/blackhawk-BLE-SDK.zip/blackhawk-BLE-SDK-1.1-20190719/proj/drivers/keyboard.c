
#include "../tl_common.h"
#include "../drivers/usbkeycode.h"
#include "keyboard.h"
#if(IS_8263)
STATIC_ASSERT_IMPLIES(HID_KEY_STANDARD, KB_RETURN_KEY_MAX==6);
//  keydrive pin ������PB,   keyscan ������PD
const u16 row_pins[] = {GPIO_PC1, GPIO_PC2, GPIO_PC3, GPIO_PC4};
const u16 col_pins[] = {GPIO_PB0, GPIO_PB1, GPIO_PB2, GPIO_PB3};

u8 kb_key_checked(void){
	u8 pc = reg_gpio_pc_in;
	return (~(pc & BITS(1,2,3,4)) >> 1) & BITS(0,1,2,3);
}
static inline u32 kb_scan_pin_value(){
	u8 pb = reg_gpio_pb_in;
	return pb & BITS(0,1,2,3);
}

static inline void kb_drive_out_high(int i){
	u16 pin = row_pins[i];
	reg_gpio_pc_out |= pin;
	reg_gpio_pc_oen &= ~pin;
	sleep_us(5);
}

static inline void kb_drive_out_disable(int i){
	u16 pin = row_pins[i];
	reg_gpio_pc_out &= ~pin;
	sleep_us(1);
	reg_gpio_pc_oen |= pin;
}

#if(0)
static void inline kb_drive_pin(u32 pin, u8 enable){
//	gpio_write(pin, 0);		// by default
	if(enable){
		reg_gpio_pb_oen &= ~pin;
	}else{
		reg_gpio_pb_oen |= pin;
	}
}
static u32 key_debounce_filter( u32 mtrx_cur[], u32 filt_en ){
    u32 kc = 0;
    static u32 mtrx_pre[ARRAY_SIZE(row_pins)];
    static u32 mtrx_last[ARRAY_SIZE(row_pins)];
    foreach_arr(i, row_pins){
        u32 mtrx_tmp = mtrx_cur[i];
        if( filt_en ){
            //mtrx_cur[i] = (mtrx_last[i] ^ mtrx_tmp) ^ (mtrx_last[i] | mtrx_tmp);  //key_matrix_pressed is valid when current and last value is the same
            mtrx_cur[i] = ( ~mtrx_last[i] & (mtrx_pre[i] & mtrx_tmp) ) | ( mtrx_last[i] & (mtrx_pre[i] | mtrx_tmp) );
        }
        if ( mtrx_cur[i] != mtrx_last[i] ) {
        	kc = 1;
        }
        mtrx_pre[i] = mtrx_tmp;
        mtrx_last[i] = mtrx_cur[i];
    }
    return kc;
}
#endif

static u8 keyhold_key;
void kb_set_hold_key(u8 k){
	keyhold_key = k;
}

#if(PAIRING_PASSKEY_EN)
extern u8 smp_kb_inputting;
#endif
//  return: 1: new data(key or key-release),  2:  old data (stable).   0: no data(unstable)
u32 kb_scan_key (kb_data_t *data){
	static u32 lastData;
	static u32 lastCheckTime;
	if((!lastCheckTime) || clock_time_exceed(lastCheckTime, 50*1000)){	// kb_key_checked �������Ǿ����ж��Ƿ��а�����Ҳ���Բ�Ҫ
		lastCheckTime = clock_time();
		
		*((u32*)data) = 0;
		if(sizeof(kb_data_t) > 4) *(((u32*)data)+1) = 0;

		u8 kc = kb_key_checked();
		if(kc){
			foreach_arr(i, row_pins){		//  ��Ҫ���жϣ���Ӱ�� RF
				if(!(kc & BIT(i))) continue;
				kb_drive_out_high(i);
				u16 val = kb_scan_pin_value();
				foreach_arr(j, col_pins){
					if(val & BIT(j)){
						data->keycode[data->cnt++] = j * ARRAY_SIZE(row_pins) + i + 1;
						if(data->cnt == KB_RETURN_KEY_MAX){
							break;
						}
					}
				}
				kb_drive_out_disable(i);

				if(data->cnt == KB_RETURN_KEY_MAX){
					break;
				}
			}
		}
		#if(PAIRING_PASSKEY_EN)
		if(smp_kb_inputting){
			keyhold_key = 0;
		}
		#endif
		if(KEYPRESS_HOLD_ENABLE && keyhold_key && 0 == data->cnt){
			data->keycode[data->cnt++] = keyhold_key;
		}
		if((!KEYPRESS_HOLD_ENABLE || 0 == keyhold_key) && lastData == *((u32*)data)){		
			#if(PAIRING_PASSKEY_EN)
			if(smp_kb_inputting){
				return 0;			// donot send, ignore
			}
			#endif
			return 2;				// long press
		}else{
			#if(PAIRING_PASSKEY_EN)
			if(smp_kb_inputting){
				smp_notify_key_input(data->keycode[0]);
			}
			#endif
			lastData = *((u32*)data);
			if(KEYPRESS_HOLD_ENABLE) keyhold_key = 0;
			#if(PAIRING_PASSKEY_EN)
			if(smp_kb_inputting){	// donot send, ignore
				return 0;
			}
			#endif
			return 1;				//  send new key
		}
	}
    return 0;
}
#endif

