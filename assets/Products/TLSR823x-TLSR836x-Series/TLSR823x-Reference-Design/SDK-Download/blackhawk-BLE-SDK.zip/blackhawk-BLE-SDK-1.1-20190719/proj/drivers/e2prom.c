#include "../../proj/tl_common.h"
#include "e2prom.h"

#define	EEPROM_I2C_ID	0xa0
#define	EEPROM_SIZE		256
#define EEPROM_WRITE_INTEVAL	5000
extern void e2prom_reset(void);

/*
void e2prom_init(){
	u8 eraseByte[8] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
	for(int i=0; i< EEPROM_SIZE; i+=8 ){
		e2prom_write(i, eraseByte, 8);
		sleep_us(EEPROM_WRITE_INTEVAL);
	}
}
*/

// adr must be 8-bytes-alighned
void e2prom_write (int adr, u8 *p, int len){
	while(len > 0){
		i2c_sim_burst_write(EEPROM_I2C_ID, adr, p, (len > 8 ? 8 : len));
		len -= 8; adr += 8; p+=8;
		sleep_us(EEPROM_WRITE_INTEVAL);
	}
}

void e2prom_read (int adr, u8 *p, int len){
	i2c_sim_burst_read(EEPROM_I2C_ID, adr, p, len);
}

