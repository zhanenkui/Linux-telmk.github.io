
#include "led.h"

#define LED_MAX_CNT			1
#define LED_RESOLUTION		(10 * CLOCK_SYS_CLOCK_1MS)	// fixed to 8ms

#if (LED_MAX_CNT == 1)
#define id 	0
#else
#define id 	i
#endif

#define PATT_ON				0	
#define PATT_OFF			-1	
#define PATT_KEEP			-2
#define LED_ON				0	
#define LED_OFF				-1	
#define LOOP_FOREVER		0xff

u8  led_wait_pattern;
// loopcnt ==0:  loop forever
// !!!  offCnt ����Ϊ0 !!!
// ��� onCnt Ϊ 0, �Ͳ������
const led_pattern_t led_pattern[] = {
	{1,		1,		LOOP_FOREVER, 	PATT_ON}, 		// always on
	{25,	25, 	1,				PATT_OFF},		// 1
	{25,	25,		LOOP_FOREVER,	PATT_OFF},		// 2
	{50,	50, 	5,				PATT_OFF},		// 3
	{10,	10, 	LOOP_FOREVER,	PATT_OFF},		// 4
	{25,	25, 	2,				PATT_OFF},		// 5
	{30,	0, 		1,				PATT_KEEP},		// on: 300ms --> KEEP until new patter setted
};
//  led_set_pattern(0, 6); led_wait_pattern = 1;				// on: 300ms (mean while, no other pattern can be set.), afterward wait until new patter


led_ctrl_t  led_ctrl[LED_MAX_CNT] = {
	{PATT_OFF, 0},
#if(LED_MAX_CNT > 1)
	{PATT_OFF, 0},
#endif		
};

static void led_on(u8 i){
	gpio_write(GPIO_LED, 1);
	led_ctrl[id].curState = LED_ON;
	const led_pattern_t *pattern = &led_pattern[ led_ctrl[i].curPatt ];
	led_ctrl[id].led_time = clock_time() + pattern->onCnt * LED_RESOLUTION;
}

static void led_off(u8 i){
	gpio_write(GPIO_LED, 0);
	led_ctrl[id].curState = LED_OFF;
	if(led_ctrl[id].curPatt > 0){
		const led_pattern_t *pattern = &led_pattern[ led_ctrl[i].curPatt ];
		led_ctrl[id].led_time = clock_time() + pattern->offCnt * LED_RESOLUTION;
	}
}
/////////////////////////////////////////////////////////
void led_set_pattern_i(u8 i, s8 patt){
	led_ctrl[id].curPatt = patt;
	led_ctrl[id].stateCnt = 0;
	led_ctrl[id].loopCnt = 0;
	if(patt >= 0 && led_pattern[patt].onCnt){
		led_on(id);
	}else if(PATT_KEEP != patt){
		led_off(id);
	}
}

void led_set_pattern(u8 i, s8 patt){
	if(led_ctrl[id].curPatt == patt || led_wait_pattern) return;
	led_set_pattern_i(i, patt);
}

/////////////////////////////////////////////////
// return  0: don't care; else  next wakeup tick
u32 led_loop(void){
#if(EXT_TIMER_WAKEUP_EN)
	u32 wakeupTime = 0;
#endif
	for(int i = 0; i < LED_MAX_CNT; ++i){
		if(led_ctrl[i].curPatt <= 0){
			continue;
		}
		const led_pattern_t *pattern = &led_pattern[ led_ctrl[i].curPatt ];
		u32 diff = (u32)(led_ctrl[i].led_time - clock_time());
		// diff < LED_RESOLUTION �����1 �Ǳ����; Ϊ�˱���wakeup �����ɴ���һ��BLE interval
		if(diff < LED_RESOLUTION || diff > U31_MAX){	//	off time exceed  // if pattern->onCnt == 0,  always  on
			if(LED_ON == led_ctrl[i].curState && pattern->offCnt > 0){
				led_off(i);
			}else{
				++led_ctrl[i].loopCnt;
				if(pattern->loopCnt == LOOP_FOREVER || led_ctrl[i].loopCnt < pattern->loopCnt){	// loop forever
					led_on(i);
				}else{
					led_wait_pattern = 0;
					led_set_pattern(i, pattern->nextPatt);
				}
			}
		}
		#if(EXT_TIMER_WAKEUP_EN)
		if(led_ctrl[i].curPatt > 0){
			u32 now = clock_time();
			if(!wakeupTime || ((u32)(led_ctrl[i].led_time - now) < (u32)(wakeupTime - now))){
				wakeupTime = led_ctrl[i].led_time;
			}
		}
		#endif
	}
#if(EXT_TIMER_WAKEUP_EN)
	return wakeupTime;
#else
	return 0;
#endif
}

void led_init(void){}

