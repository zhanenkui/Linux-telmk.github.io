
#pragma once

#include "../common/types.h"
#include "../drivers/register.h"
#include "../drivers/clock.h"
#include "../drivers/analog.h"

/*

1, clock_time()
2, REG_ADDR16(0x24)
3, RF ���ջ����У����� pkt ��ʱ��
4, cache �е�����
5, ���� IO �� adc ��ֵ

*/

static inline u16 myrand(void){
#if(IS_SW_BLE)
	return (u16)((clock_time() & 0xffff) ^ REG_ADDR16(0x24));
#elif(IS_8258 || IS_8369)
	u8 tmp2 = analog_read(0x80 + 117);
	u8 tmp1 = analog_read(0x80 + 118);
	return (tmp1 << 8) + tmp2;
#else	
	return (u16)((clock_time() & 0xffff) ^ reg_rnd_number);
#endif	
	
}

#if(IS_8258 || IS_8369)
static inline void rand_set(u8 source, u8 updateType){		// rand_mode_e, rand_update_e
	analog_write(0x80 + 126, source | updateType);			//Set
}
#endif

