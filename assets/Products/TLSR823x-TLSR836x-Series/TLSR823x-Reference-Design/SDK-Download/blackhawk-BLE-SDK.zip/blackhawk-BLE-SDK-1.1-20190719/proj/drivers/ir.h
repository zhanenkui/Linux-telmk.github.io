
#include "../tl_common.h"
#include "pwm.h"

#define IR_USE_TIMER		0

#define IR_PROTOCOL_NEC		1
#define IR_PROTOCOL_TC9012	2

#define IR_PROTOCOL			IR_PROTOCOL_NEC
#define IR_USE_PWMIRMODE	(IS_8369 || IS_8258)					// PWM IR mode
#define IR_USE_PWM			(!IR_USE_PWMIRMODE)
#define IR_PWM_ID			(IR_USE_PWMIRMODE?0:2)

#define IR_CARRIER_FRE				38000
#if(IR_PROTOCOL == IR_PROTOCOL_NEC)
#define IR_HIGH_CARR_TIME			560			// in us
#define IR_HIGH_NO_CARR_TIME		1685
#define IR_LOW_CARR_TIME			560
#define IR_LOW_NO_CARR_TIME			560
#define IR_INTRO_CARR_TIME			9000
#define IR_INTRO_NO_CARR_TIME		4500
#define IR_REPEAT_NO_CARR_TIME      2250
#else
#define IR_HIGH_CARR_TIME	        560
#define IR_HIGH_NO_CARR_TIME		1690
#define IR_LOW_CARR_TIME            560
#define IR_LOW_NO_CARR_TIME         560
#define IR_INTRO_CARR_TIME          4500
#define IR_INTRO_NO_CARR_TIME       4500
#endif
#define IR_STOP_CARRIER_TIME		(560)
#define IR_STOP_NO_CARRIER_TIME 	(500)

#define IR_SPACE_TIME				(108500)

typedef struct{
	u16 *time_series;
	u8 type;
	u8 start_high;
	u8 series_cnt;
	u8 code;
}ir_send_ctrl_data_t;
typedef struct{
	u32 cnt;
	#if(IR_USE_PWMIRMODE)
	u16	data[6 + 32*2];			//  start + (client + cmd) * 2
	#else
	ir_send_ctrl_data_t	data[6];
	#endif
	u8 index;
	u8 is_sending;
}ir_send_ctrl_t;

void ir_send_cmd(u8 client_code, u8 client_code1, u8 cmd);
void ir_init(void);
void ir_repeat_check();

///  ir learning //////////////////////////////////
#define IR_LEARN_NEC				0

#define IR_LEARN_NONE_CARR_MIN		100		//  in us
#define IR_LEARN_CARR_GLITCH_MIN	4
#define IR_LEARN_STOP_TIME			(20*1000)	//  in us

#define IR_LEARN_SERIES_CNT			80
#define IR_LEARN_TIMEOUT			(10*1000*1000)	// in us
#define IR_LEARN_START_MIN			(1000)			// in us
#define IR_LEARN_STORED_ADDRESS 	(0x8000)

typedef struct{
	u8 pol;					// last IR input voltage level
	u8 series_cnt;			// waveform bits count
	u16 pulse_cnt;			// 
#if(IR_LEARN_NEC)
	u32 code;
#else
	u32 carr_tick;			// Use to calculate frequency and duty cycle
	u32 cycle_tick;			// Use to calculate frequency and duty cycle
	u16 series[IR_LEARN_SERIES_CNT];
#endif
	u32 carr_tm;			// active
	u32 none_carr_tm;		// inactive
	u32 carr_start_tm;		// the start time of carrier of each bit
	u8  learn_done;
	u8	leading_found;
}ir_learn_ctrl_t;


