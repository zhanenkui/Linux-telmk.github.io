
#pragma once

#include "../../proj/tl_common.h"

typedef struct {
	u8 onCnt;			//  in 8 ms unit
	u8 offCnt;			//  in 8 ms unit
	u8 loopCnt;
	s8 nextPatt;
}led_pattern_t;

typedef struct {
	s8 curPatt;
	s8 curState;
	s8 stateCnt;
	s8 loopCnt;
	u32 led_time;
}led_ctrl_t;

void led_set_pattern(u8 led, s8 pat);
u32 led_loop(void);
void led_init(void);


