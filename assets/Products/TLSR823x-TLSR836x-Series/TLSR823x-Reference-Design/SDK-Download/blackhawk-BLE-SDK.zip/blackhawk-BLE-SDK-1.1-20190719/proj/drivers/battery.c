
#include "../tl_common.h"
#include "battery.h"
#include "adc.h"

STATIC_ASSERT(ADC_ENABLE);
#define MORE_PRECISE_EN		0
int batt_get_value(void){
	static int batt_val;
	#if(MORE_PRECISE_EN)
	static int remainer;
	#endif
	
	int val = adc_get_value();
	if(val > 0){
		if(0 == batt_val) batt_val = val;
		
		#if(MORE_PRECISE_EN)
		int v = (val - batt_val + remainer);
		int a = v / 16;
		int r = v - a * 16;
		batt_val += a;
		remainer += r;

		#else
		batt_val += (val - batt_val) /16;
		#endif
	}
	return batt_val;
	
}


