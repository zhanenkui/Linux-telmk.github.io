
#pragma once

enum{
	BATT_STAT_NORMAL,		//  default  to  normal
	BATT_STAT_LOW,
	BATT_STAT_FULL,
	BATT_STAT_CHARGING,
};

void batt_init(void);

