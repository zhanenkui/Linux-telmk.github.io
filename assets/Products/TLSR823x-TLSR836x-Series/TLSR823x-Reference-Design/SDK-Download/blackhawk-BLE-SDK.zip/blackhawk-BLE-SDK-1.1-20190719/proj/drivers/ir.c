
#include "../tl_common.h"
#include "timer.h"
#include "ir.h"

#if(IR_ENABLE)
STATIC_ASSERT_IMPLIES(IR_USE_TIMER, IRQ_TIMER_ENABLE);
enum{
	IR_SEND_TYPE_TIME_SERIES,
	IR_SEND_TYPE_BYTE,
};

#if(0)
extern u8 rf_tx_buff[];
static ir_send_ctrl_t * const ir_send_ctrl = rf_tx_buff;
#else
static ir_send_ctrl_t ir_send_ctrl_real;
static ir_send_ctrl_t * const ir_send_ctrl = &ir_send_ctrl_real;
#endif

u32 ir_irq_send(void);
static void ir_send_repeat(void);

static void ir_send_ctrl_clear(void){
	ir_send_ctrl->is_sending = ir_send_ctrl->cnt = ir_send_ctrl->index = 0;
}
#if(!IR_USE_PWMIRMODE)
static void ir_send_add_series_item(const u16 *time_series, u8 series_cnt, u8 start_high){
	u8 i = ir_send_ctrl->cnt;
	ir_send_ctrl->data[i].type = IR_SEND_TYPE_TIME_SERIES;
	ir_send_ctrl->data[i].time_series = time_series;
	ir_send_ctrl->data[i].series_cnt = series_cnt;
	ir_send_ctrl->data[i].start_high = start_high;
	++ir_send_ctrl->cnt;
}

static void ir_send_add_byte_item(u8 code, u8 start_high){
	u8 i = ir_send_ctrl->cnt;
	ir_send_ctrl->data[i].type = IR_SEND_TYPE_BYTE;
	ir_send_ctrl->data[i].start_high = start_high;
	ir_send_ctrl->data[i].code = code;
	++ir_send_ctrl->cnt;
}
#endif

static u8 ir_repeat_enable;
static u32 ir_repeat_timer;
#if(!IR_USE_PWMIRMODE)
void ir_repeat_check(){
	if(ir_repeat_enable && clock_time_exceed(ir_repeat_timer, IR_SPACE_TIME)){
		ir_repeat_timer = clock_time();
		ir_send_repeat();
	}
}
#endif

static u8 ir_send_irq_idx;
static u8 ir_send_start_high;
static void ir_send_ctrl_start(int need_repeat){
	ir_repeat_enable = need_repeat;
	#if(!IR_USE_PWMIRMODE)
	ir_repeat_timer = clock_time();
	#endif
#if(IR_USE_PWMIRMODE)
	pwm_set_dma_addr(ir_send_ctrl);
	pwm_ir_dma_fifo_start_tx();
	pwm_clear_irq_status(FLD_IRQ_PWM0_IR_DMA_FIFO_DONE);
	pwm_set_irq_en(FLD_IRQ_PWM0_IR_DMA_FIFO_DONE, 1);
#else
	ir_send_irq_idx = 0;
	ir_send_ctrl->index = 0;
	ir_send_ctrl->is_sending = 1;
	#if(IR_USE_TIMER)
	ir_irq_send();
	#else
	while(1){
		u32 t = ir_irq_send();
		if(0 == t){
			ir_send_irq_idx = 0;
		}else if(U32_MAX == t){
			break;
		}else{
			sleep_us(t);
		}
	}
	#endif
#endif
}

void ir_send_release(void){
	ir_send_ctrl_clear();
	ir_repeat_enable = 0;
}

#if(IR_USE_PWMIRMODE)
static inline void ir_stop(void){
	pwm_set_irq_en(FLD_IRQ_PWM0_IR_DMA_FIFO_DONE, 0);
}
#endif
static inline u32 ir_get_byte_time(u8 code, u8 index){
	u8 b = index / 2;
	u8 r = index & 1;
	if(code & BIT(b)){
		if(!r){
			return IR_HIGH_CARR_TIME;
		}else{
			return IR_HIGH_NO_CARR_TIME;
		}
	}else{
		if(!r){
			return IR_LOW_CARR_TIME;
		}else{
			return IR_LOW_NO_CARR_TIME;
		}
	}
}
#if(!IR_USE_PWMIRMODE)
#if(IR_USE_TIMER)
_attribute_ram_code_
#endif
u32 ir_irq_send(void){
	u32 t = 0;
	u8 end = 0;

	u8 i = ir_send_ctrl->index;
	if(IR_SEND_TYPE_TIME_SERIES == ir_send_ctrl->data[i].type){
		if(ir_send_irq_idx < ir_send_ctrl->data[i].series_cnt){
			t = ir_send_ctrl->data[i].time_series[ir_send_irq_idx];
		}else{
			end = 1;
		}
	}else{
		if(ir_send_irq_idx < 16){
			t = ir_get_byte_time(ir_send_ctrl->data[i].code, ir_send_irq_idx);
		}else{
			end = 1;
		}
	}
	
	if(end){
		++ir_send_ctrl->index;
		if(ir_send_ctrl->index < ir_send_ctrl->cnt){
			#if(IR_USE_TIMER)
			ir_send_irq_idx = 0;
			ir_irq_send();
			#endif
			return 0;
		}else{
			ir_send_ctrl->is_sending = 0;
			pwm_stop(IR_PWM_ID);
			#if(IR_USE_TIMER)
			timer_disable_timer(1);
			#endif
			return U32_MAX;
		}
	}else if(0 == ir_send_irq_idx){		// start
		ir_send_start_high = ir_send_ctrl->data[i].start_high;
		#if(IR_USE_TIMER)
		timer_enable_timer(1);
		#endif
	}
	if(ir_send_start_high){
		pwm_start(IR_PWM_ID);
	}else{
		pwm_stop(IR_PWM_ID);
	}
	#if(IR_USE_TIMER)
	timer_set_timeout(1, t*CLOCK_RUN_CLOCK_1US);
	#endif	
	++ir_send_irq_idx;
	ir_send_start_high = !ir_send_start_high;
	return t;
	
}
#endif
int ir_is_sending(){
	//  in case timer irq missing, must long enough, in case sys sleep and wakeup, 
	return ir_send_ctrl->is_sending;
}

/////////////  NEC  && Toshiba protocol  /////////////////////////////////////////////
static u8 ir_client_code;
static void ir_send_repeat(void){
	if(ir_is_sending()){
		return;
	}
	ir_send_ctrl_clear();
#if(IR_USE_PWMIRMODE)
	u8 cnt = 0;
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_INTRO_CARR_TIME * IR_CARRIER_FRE/1000000));

	#if(IR_PROTOCOL == IR_PROTOCOL_NEC)
	const u32 irSendTime = IR_SPACE_TIME - (IR_INTRO_CARR_TIME + IR_REPEAT_NO_CARR_TIME + IR_LOW_CARR_TIME);
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_REPEAT_NO_CARR_TIME * IR_CARRIER_FRE/1000000));

	#elif(IR_PROTOCOL == IR_PROTOCOL_TC9012)

	u32 irSendTime = IR_SPACE_TIME - (IR_INTRO_CARR_TIME + IR_INTRO_NO_CARR_TIME + IR_LOW_CARR_TIME);
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_INTRO_NO_CARR_TIME * IR_CARRIER_FRE/1000000));
	if(ir_client_code & 1){
		ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_LOW_CARR_TIME * IR_CARRIER_FRE/1000000));
		ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_LOW_NO_CARR_TIME * IR_CARRIER_FRE/1000000));
		irSendTime -= IR_LOW_CARR_TIME + IR_LOW_NO_CARR_TIME;
	}else{
		ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_HIGH_CARR_TIME * IR_CARRIER_FRE/1000000));
		ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_HIGH_NO_CARR_TIME * IR_CARRIER_FRE/1000000));
		irSendTime -= IR_HIGH_CARR_TIME + IR_HIGH_NO_CARR_TIME;
	}
	#endif
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_LOW_CARR_TIME * IR_CARRIER_FRE/1000000));
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (irSendTime * IR_CARRIER_FRE/1000000));
	ir_send_ctrl->cnt = cnt * 2;
#else
	#if(IR_PROTOCOL == IR_PROTOCOL_NEC)
	const u16 ir_times[] = {IR_INTRO_CARR_TIME, IR_REPEAT_NO_CARR_TIME, IR_LOW_CARR_TIME};
	ir_send_add_series_item(ir_times, ARRAY_SIZE(ir_times), 1);
	#else
	const u16 ir_times0[] = {IR_INTRO_CARR_TIME, IR_INTRO_NO_CARR_TIME, IR_LOW_CARR_TIME, IR_LOW_NO_CARR_TIME, IR_LOW_CARR_TIME};
	const u16 ir_times1[] = {IR_INTRO_CARR_TIME, IR_INTRO_NO_CARR_TIME, IR_HIGH_CARR_TIME, IR_HIGH_NO_CARR_TIME, IR_LOW_CARR_TIME};
	if(ir_client_code & 1){
		ir_send_add_series_item(ir_times0, ARRAY_SIZE(ir_times0), 1);
	}else{
		ir_send_add_series_item(ir_times1, ARRAY_SIZE(ir_times1), 1);
	}
	#endif
#endif
	ir_send_ctrl_start(1);
	
}

const u16 ir_lead_times[] = {IR_INTRO_CARR_TIME, IR_INTRO_NO_CARR_TIME};
const u16 ir_stop_bit_times[] = {IR_STOP_CARRIER_TIME};
void ir_send_cmd(u8 client_code, u8 client_code1, u8 cmd){
	if(ir_is_sending()){
		return;
	}
	ir_send_ctrl_clear();

#if(IR_USE_PWMIRMODE)
	u32 irSendTime = IR_SPACE_TIME - (IR_INTRO_CARR_TIME + IR_INTRO_NO_CARR_TIME + IR_STOP_CARRIER_TIME);		//  fixed time

	u8 cnt = 0;
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_INTRO_CARR_TIME * IR_CARRIER_FRE/1000000));
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_INTRO_NO_CARR_TIME * IR_CARRIER_FRE/1000000));

	u32 irCode = ((~cmd)<<24) | (cmd<<16) | (client_code1<<8) | client_code;
	for(int i = 0; i < 32; i++){
		if(irCode & BIT(i)){			//Logic "1"
			ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_HIGH_CARR_TIME * IR_CARRIER_FRE/1000000));
			ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_HIGH_NO_CARR_TIME * IR_CARRIER_FRE/1000000));
			irSendTime -= IR_HIGH_CARR_TIME + IR_HIGH_NO_CARR_TIME;
		}else{							//Logic "0"
			ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_LOW_CARR_TIME * IR_CARRIER_FRE/1000000));
			ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (IR_LOW_NO_CARR_TIME * IR_CARRIER_FRE/1000000));
			irSendTime -= IR_LOW_CARR_TIME + IR_LOW_NO_CARR_TIME;
		}
	}
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(1, 0, (IR_STOP_CARRIER_TIME * IR_CARRIER_FRE/1000000));
	ir_send_ctrl->data[cnt++] = pwm_ir_dma_fifo_set_waveform(0, 0, (irSendTime * IR_CARRIER_FRE/1000000));
	ir_send_ctrl->cnt = cnt * 2;		// bytes count
#else
	ir_send_add_series_item(ir_lead_times, ARRAY_SIZE(ir_lead_times), 1);
	ir_send_add_byte_item(client_code, 1);
	ir_send_add_byte_item(client_code1, 1);
	ir_send_add_byte_item(cmd, 1);
	ir_send_add_byte_item(~cmd, 1);
	ir_send_add_series_item(ir_stop_bit_times, ARRAY_SIZE(ir_stop_bit_times), 1);
#endif
#if(IR_PROTOCOL == IR_PROTOCOL_TC9012)
	ir_client_code = client_code;
#endif
	ir_send_ctrl_start(1);

}
#if(IR_USE_PWMIRMODE)
void ir_irqHandler(void){
	if(pwm_get_irq_status(FLD_IRQ_PWM0_IR_DMA_FIFO_DONE)){
		if(ir_repeat_enable){
			ir_send_repeat();
		}else{
			ir_stop();
		}
		pwm_clear_irq_status(FLD_IRQ_PWM0_IR_DMA_FIFO_DONE);
	}
}
#endif
STATIC_ASSERT(!(IR_USE_PWMIRMODE && IR_USE_PWM));
STATIC_ASSERT_IMPLIES(IR_USE_PWMIRMODE, 0 == IR_PWM_ID);
void ir_init(void){
#if(IR_USE_PWM)
	pwm_set_max_and_cmp(IR_PWM_ID, CLOCK_RUN_CLOCK_1S / IR_CARRIER_FRE, CLOCK_RUN_CLOCK_1S / (IR_CARRIER_FRE * 3));	// freq: 38K
#elif(IR_USE_PWMIRMODE)
	pwm_set_max_and_cmp(IR_PWM_ID, CLOCK_RUN_CLOCK_1S / IR_CARRIER_FRE, CLOCK_RUN_CLOCK_1S / (IR_CARRIER_FRE * 3));	// freq: 38K
	pwm_set_mode(PWM_IR_DMA_FIFO_MODE);
	pwm_set_pol(IR_PWM_ID, 1); 	//	falling edge
#endif
}
#endif

#if(0)
//////////////////   learn  waveforms ////////////////////////
#if(0)
extern unsigned int ctx_ks[4 * 11];
static ir_learn_ctrl_t * const ir_learn_ctrl = ctx_ks;
#else
static ir_learn_ctrl_t ir_learn_ctrl_real;
static ir_learn_ctrl_t * const ir_learn_ctrl = &ir_learn_ctrl_real;
#endif
void ir_learn_init(){
	memset(ir_learn_ctrl, 0, sizeof(ir_learn_ctrl_t));
	ir_learn_ctrl->pol = 1;
	ir_learn_ctrl->none_carr_tm = ir_learn_ctrl->carr_tm = clock_time();
}

//// !!!!!  Negative Logic:  pol == 0 if carrier sending
int ir_learn(u32 tm, u32 pol){
	if(ir_learn_ctrl->series_cnt >= IR_LEARN_SERIES_CNT || ir_learn_ctrl->learn_done){	//	FULL
		return 1;
	}
	if(pol != ir_learn_ctrl->pol){	//	edge triggered
		if(pol){					//	none carrier
			u32 inact_intvl = ir_learn_ctrl->carr_tm - ir_learn_ctrl->none_carr_tm;				// none carrier one pulse interval
			u32 act_intvl = tm - ir_learn_ctrl->carr_tm; 										// carrier	one pulse interval
			if(act_intvl > (IR_LEARN_CARR_GLITCH_MIN*CLOCK_SYS_CLOCK_1US)){ 					// must not a glitch
				if(0 == ir_learn_ctrl->pulse_cnt){												// the first carrier pulse
					ir_learn_ctrl->carr_start_tm = ir_learn_ctrl->carr_tm;						// remember the carrier start time
				}else if(inact_intvl > (IR_LEARN_NONE_CARR_MIN*CLOCK_SYS_CLOCK_1US)){			// last BIT finished, new bit started
					u32 carr_intvl = ir_learn_ctrl->none_carr_tm - ir_learn_ctrl->carr_start_tm;	// the carrier lasting interval of one bit
					
					if(!ir_learn_ctrl->series_cnt && (!IR_LEARN_NEC || ir_learn_ctrl->leading_found)){												// leading pulse ???
						if(carr_intvl < IR_LEARN_START_MIN*CLOCK_SYS_CLOCK_1US){				// not valid leading pulse 
							ir_learn_init();													// the leading pulse must long enough
							return 0;
						}
						// got valid leading pulse, cal freq and duty
						ir_learn_ctrl->leading_found = 1;
				#if(!IR_LEARN_NEC)
						ir_learn_ctrl->cycle_tick = carr_intvl / ir_learn_ctrl->pulse_cnt;
						ir_learn_ctrl->carr_tick /= ir_learn_ctrl->pulse_cnt;
				#endif
						
					}
				#if(IR_LEARN_NEC)
					if(carr_intvl < (IR_LOW_CARR_TIME + IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US
						&& carr_intvl > (IR_LOW_CARR_TIME - IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US){
						if(inact_intvl < (IR_LOW_NO_CARR_TIME + IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US
							&& inact_intvl > (IR_LOW_NO_CARR_TIME - IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US){
							ir_learn_ctrl->code <<= 1;
						}else if(inact_intvl < (IR_HIGH_NO_CARR_TIME + IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US
							&& inact_intvl > (IR_HIGH_NO_CARR_TIME - IR_LEARN_NONE_CARR_MIN)*CLOCK_SYS_CLOCK_1US){
							ir_learn_ctrl->code <<= 1; ir_learn_ctrl->code |= 1;
						}
						ir_learn_ctrl->series_cnt++;
						if(32 == ir_learn_ctrl->series_cnt) return ir_learn_ctrl->code;
					}
				#else
					ir_learn_ctrl->series[ir_learn_ctrl->series_cnt++] = carr_intvl/CLOCK_SYS_CLOCK_1US;	// save last bit 
					ir_learn_ctrl->series[ir_learn_ctrl->series_cnt++] = inact_intvl/CLOCK_SYS_CLOCK_1US; // save last bit
				#endif
					ir_learn_ctrl->carr_start_tm = ir_learn_ctrl->carr_tm;						// refresh carr_start_tm
				}
				#if(!IR_LEARN_NEC)
				if(!ir_learn_ctrl->leading_found) ir_learn_ctrl->carr_tick += act_intvl;			// accumulate the carr acitve time
				#endif
				ir_learn_ctrl->none_carr_tm = tm;												// remember none-carrier pulse edge
				++ir_learn_ctrl->pulse_cnt;
			}
		}else{
			ir_learn_ctrl->carr_tm = tm; 														// remember carrier pulse edge
		}
		ir_learn_ctrl->pol = pol;
	}
	else{
		if(pol && clock_time_exceed(ir_learn_ctrl->none_carr_tm, IR_LEARN_STOP_TIME) && ir_learn_ctrl->leading_found){
			if(ir_learn_ctrl->leading_found){
				ir_learn_ctrl->learn_done = 1;
				ir_learn_ctrl->series[ir_learn_ctrl->series_cnt++] = (ir_learn_ctrl->none_carr_tm - ir_learn_ctrl->carr_start_tm)/CLOCK_SYS_CLOCK_1US;	// save last bit 
				ir_learn_ctrl->series[ir_learn_ctrl->series_cnt++] = IR_LEARN_STOP_TIME; // save last bit
			}
		#if(IR_LEARN_NEC)
			return 0;
		#else
			return ir_learn_ctrl->series_cnt;
		#endif
		}
	}
	return 0;
}


#define IR_ONE_CYCLE_TICK  ((u32)(26.316 * CLOCK_SYS_CLOCK_1US))
#define IR_CARR_HIGH_TICK  ((u32)(8.772 * CLOCK_SYS_CLOCK_1US))
#define CARRIER_LEVEL 		0

typedef struct{
	int is_carr;
	int duration;
}IR_TEST_CTRL;

void ir_learn_test(void){
    //NEC protocol
    const static IR_TEST_CTRL ir_test_ctrl[] = 
    {{0, 200}, 
    {1, 9000}, {0, 4500},//INTRO CODE
    //ae69 56c3            
    {1, 560}, {0, 1690},//BIT8; 1100
    {1, 560}, {0, 1690},
    {1, 560}, {0, 560}, 
    {1, 560}, {0, 550},

    {1, 560}, {0, 560},//BIT12; 0011
    {1, 560}, {0, 560},
    {1, 560}, {0, 1690}, 
    {1, 560}, {0, 1690},
                
    {1, 560}, {0, 560},//BIT 0 ; 0110
    {1, 560}, {0, 1690},
    {1, 560}, {0, 1690}, 
    {1, 560}, {0, 560},

    {1, 560}, {0, 1690},//BIT4 ; 1010
    {1, 560}, {0, 560},
    {1, 560}, {0, 1690}, 
    {1, 560}, {0, 560},

    {1, 560}, {0, 1690},//BIT16; 1001
    {1, 560}, {0, 560},
    {1, 560}, {0, 560}, 
    {1, 560}, {0, 1690},

    {1, 560}, {0, 570},//BIT20; 0110
    {1, 570}, {0, 1700},
    {1, 550}, {0, 1700}, 
    {1, 560}, {0, 550},

    {1, 560}, {0, 570},//BIT24; 0111
    {1, 570}, {0, 1700},
    {1, 550}, {0, 1700}, 
    {1, 560}, {0, 1690},

    {1, 560}, {0, 560},//BIT28; 0101
    {1, 560}, {0, 1690},
    {1, 560}, {0, 560}, 
    {1, 560}, {0, 1690},//BIT31

      
    {1, 560} /*end*/, {0, 18000}, {1, 9000}/*repeat*/};        

	ir_learn_init();
	int trig_pol = CARRIER_LEVEL;
	u32 start_time = clock_time();
	u32 duration = 0;
	for(int i = 0; i < sizeof(ir_test_ctrl) / sizeof(IR_TEST_CTRL); ++i){
		u32 duration1 = duration + ir_test_ctrl[i].duration * CLOCK_SYS_CLOCK_1US;
		if(ir_test_ctrl[i].is_carr){
			trig_pol = CARRIER_LEVEL;
			while(!clock_time_exceed_tick(start_time, duration1)){
				if(trig_pol == CARRIER_LEVEL){
					duration += IR_CARR_HIGH_TICK;
					if(duration >= duration1) duration = duration1;
					while(!clock_time_exceed_tick(start_time, duration)){
						if(ir_learn(clock_time(), trig_pol)) goto ir_learn_done;
					}
				}else{
					duration += IR_ONE_CYCLE_TICK - IR_CARR_HIGH_TICK;
					if(duration >= duration1) duration = duration1;
					while(!clock_time_exceed_tick(start_time, duration)){
						if(ir_learn(clock_time(), trig_pol)) goto ir_learn_done;
					}
				}
				trig_pol = !trig_pol;
			}
		}else{
			while(!clock_time_exceed_tick(start_time, duration1)){
				if(ir_learn(clock_time(), !CARRIER_LEVEL))  goto ir_learn_done;
			}
		}
		duration = duration1;
	}
ir_learn_done:
		duration = duration;
	
}

//////////////////////////////////////////////////
STATIC_ASSERT(sizeof(ir_learn_ctrl_t) <= 256);
void ir_save_learn_data(){
	flash_erase_sector(IR_LEARN_STORED_ADDRESS);
	flash_write_page(IR_LEARN_STORED_ADDRESS, sizeof(ir_learn_ctrl_t), (u8*)(ir_learn_ctrl));
}

int ir_send_learn_init(u8 loaded){
	if(0 == loaded){
		memset(ir_learn_ctrl, 0, sizeof(ir_learn_ctrl_t));
		flash_read_page(IR_LEARN_STORED_ADDRESS, sizeof(ir_learn_ctrl_t), (u8*)(ir_learn_ctrl));
	}
	#if(!IR_LEARN_NEC)
	if(ir_learn_ctrl->series_cnt > 0 && ir_learn_ctrl->series_cnt < 0xff){
		pwm_set(IR_PWM_ID, ir_learn_ctrl->cycle_tick, ir_learn_ctrl->carr_tick);
		return 1;
	}
	#endif
	return 0;
}

void ir_send_learn(){
#if(IR_LEARN_NEC)
	u8* code = (u8*)(&ir_learn_ctrl->code);
	ir_send_cmd(code[3], code[2], code[1]);
#else	
	ir_send_ctrl_clear();
	ir_send_add_series_item(ir_learn_ctrl->series, ir_learn_ctrl->series_cnt, 1);
	ir_send_ctrl_start(0);
#endif

}
#endif

