
#include "register.h"
#include "analog.h"
#include "clock.h"
#include "pm.h"
#include "rf_drv.h"
#include "timer.h"

#define	RF_MANUAL_AGC_MAX_GAIN		1
#define TX_GAIN    					0x93//register address of TP value
unsigned char rf_nesn;
//BLE 1M mode
#define	TP_1M_G0	0x3b
#define	TP_1M_G1	0x33
//BLE 2M mode
#define TP_2M_G0	0x4a//0x47  //channel id:2402
#define	TP_2M_G1	0x42//0x3f  //channel id:2480

#define	TP_GET_GAIN(g0, g1)	  ((g0 - g1)*256/80)
int	rf_tp_base = TP_1M_G0;
int	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);

static RF_StatusTypeDef RF_TRxState = RF_MODE_TX;
const unsigned char rf_chn[MAX_RF_CHANNEL] = {
	FRE_OFFSET+ 5, FRE_OFFSET+ 9, FRE_OFFSET+13, FRE_OFFSET+17,
	FRE_OFFSET+22, FRE_OFFSET+26, FRE_OFFSET+30, FRE_OFFSET+35,
	FRE_OFFSET+40, FRE_OFFSET+45, FRE_OFFSET+50, FRE_OFFSET+55,
	FRE_OFFSET+60, FRE_OFFSET+65, FRE_OFFSET+70, FRE_OFFSET+76,
};

/**
 * @Brief: RF Base Initialization Table
 */

static void tbl_rf_init_write(void)
 {
	analog_write(0x01, 0x77);	 //lna/mixer ldo trim
	analog_write(0x06, 0x00);	 //lna/mixer ldo trim
	analog_write(0x82, 0x5f);
	analog_write(0x8b, 0x4a);
	analog_write(0x8d, 0x61);

	analog_write(0xa0, 0x03); 	//dac datapath delay ******change  remington 0x26	(fix)
	//set TX power, actually no need, rf_set_power_level_index()  will update the value
	analog_write(0xa2, 0x2c); 	//pa_ramp_target ****0-5bit //TX power
	analog_write(0xa8, 0x62);
	analog_write(0xac, 0xa7); 	//RX bandwidth setting: 0xaa -> 0xa7 ,widen 15%
	analog_write(0xaa, 0x26);

	WRITE_REG8(0x4d4, 0x8f);
	WRITE_REG8(0x4d5, 0x02);
	WRITE_REG8(0xf16, 0x29);
	WRITE_REG8(0x42d, 0xb3);	// DC alpha=1/8, [6:4] r_predcoc_bw: [0,6], pwrDft 0x63,6-> 3  (Change from 0xb3,Increase trailor length and solve the high-bit CRC error)
	WRITE_REG8(0x439, 0x6e);	//RX RSSI offset, pwrDft 0x6e
	WRITE_REG8(0x4cd, 0x66);
	WRITE_REG8(0xf04, 0x68);
	//must
	WRITE_REG8(0xf06, 0x00);	//rx wait settle time: 1us 0x00
	WRITE_REG8(0xf0c, 0x50);	//rx settle time: 80us 0x50
	WRITE_REG8(0xf10, 0x00);	//wait time on NAK 000 0x00
}
/**
 * @Brief: BLE 1M Initialization Table
 */


static void tbl_rf_ble_1m_write(void)
{
	analog_write(0x8f, 0x2b);
	analog_write(0x93, 0x38);
	analog_write(0x9e, 0x56);
	analog_write(0xa3, 0xf0);	//********[7:6] disable gauflt [5] LUT 2M or 1M
	analog_write(0xaa, 0x26);	//1MHz /
	//BLE 1M setting    /*
	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x401, 0x01);
	WRITE_REG8(0x402, 0x26);	// 6-byte pre-amble
	WRITE_REG8(0x404, 0xf5);	// head_mode/crc_mode: normal c0; 0xf7 for RX shockburst
	WRITE_REG8(0x405, 0x04);	// access code length 4

	WRITE_REG8(0x420, 0x1f);	// threshold  31/32
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x422, 0x00);	// threshold 0x00
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4] 0x12
	WRITE_REG8(0x42b, 0xf1);	// access code: 1
	WRITE_REG8(0x428, 0x80);

	WRITE_REG8(0x42c,0xff); // maxiumum length 224 byte

	WRITE_REG8(0x43b, 0xfc);
	WRITE_REG8(0x464, 0x07);
	WRITE_REG8(0xf03, 0x1e);	// bit3: crc2_en; normal 1e
}
/**
 * @Brief: BLE 2M Initialization Table
 */

static void tbl_rf_ble_2m_write(void)
{
	analog_write(0x8f, 0x32);
	analog_write(0x93, 0x43);
	analog_write(0x9e, 0xad);
	analog_write(0xa3, 0xd0);	//********[7:6] disable gauflt [5] LUT 2M or 1M
	analog_write(0xaa, 0x2e);	//2MHz /
	//BLE 2M setting    /*
	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x401, 0x08);	// pn enable

	WRITE_REG8(0x404, 0xe5);	// head_mode/crc_mode: normal c0; 0xf7 for RX shockburst

	WRITE_REG8(0x402, 0x86);	//change from 0x26,Increase trailor length and solve the high-bit CRC error
	WRITE_REG8(0x405, 0x04);	// access code length 4
	WRITE_REG8(0x420, 0x1f);	// threshold  31/32
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x422, 0x00);	// threshold 0x00
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4] 0x12

	WRITE_REG8(0x428, 0x80);
	WRITE_REG8(0x42c, 0xff);
	WRITE_REG8(0x42b, 0xf1);	// access code: 1


	WRITE_REG8(0x43b, 0xfc);
	WRITE_REG8(0x464, 0x07);
	WRITE_REG8(0xf03, 0x1e);	// bit3: crc2_en; normal 1e
	}

/**
 * @Brief: BLE 2M disable PN Initialization Table
 */
static void tbl_rf_2m_no_pn_write(void)
{
	analog_write(0x8f, 0x32);
	analog_write(0x93, 0x43);
	analog_write(0x9e, 0xad);
	analog_write(0xa3, 0xd0);   //Increase trailor length and solve the high-bit CRC error
	analog_write(0xaa, 0x2e);
	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x401, 0x00);	// pn enable
	WRITE_REG8(0x404, 0xc5);	// head_mode/crc_mode: normal c0; 0xf7 for RX shockburst

	WRITE_REG8(0x402, 0x8b);    //change from 0x26,Increase trailor length and solve the high-bit CRC error
	WRITE_REG8(0x405, 0x04);	// access code length 4

	WRITE_REG8(0x420, 0x1f);	// threshold  31/32
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x422, 0x00);	// threshold 0x00
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4] 0x12
	WRITE_REG8(0x428, 0x80);
	WRITE_REG8(0x42c, 0xff);    // maxiumum length 224 byte
	WRITE_REG8(0x42b, 0xf1);	// access code: 1

	WRITE_REG8(0x46e, 0x00);
	WRITE_REG8(0x43b, 0xfc);
	WRITE_REG8(0x464, 0x07);
	WRITE_REG8(0xf03, 0x1e);	// bit3: crc2_en; normal 1e
}
/**
 * @Brief: BLE 1M disable PN Initialization Table
 */
static void tbl_rf_ble_1m_no_pn_write(void)
{
	analog_write(0x8f, 0x2b);
	analog_write(0x93, 0x38);
	analog_write(0x9e, 0x56);
	analog_write(0xa3, 0xf0);
	analog_write(0xaa, 0x26);

	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x401, 0x00);	// pn disable
	WRITE_REG8(0x402, 0x26);
	WRITE_REG8(0x404, 0xd5);	// head_mode/crc_mode: normal c0; 0xf7 for RX shockburst
	WRITE_REG8(0x405, 0x04);	// access code length 4

	WRITE_REG8(0x420, 0x1f);	// threshold  31/32
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x422, 0x00);	// threshold 0x00
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4] 0x12
	WRITE_REG8(0x42b, 0xf1);	// access code: 1
	WRITE_REG8(0x428, 0x80);

	WRITE_REG8(0x42c, 0xff); // maxiumum length 224 byte

	WRITE_REG8(0x46e, 0x00);
	WRITE_REG8(0x43b, 0xfc);
	WRITE_REG8(0x464, 0x07);
	WRITE_REG8(0xf03, 0x1e);	// bit3: crc2_en; normal 1e

}
/**
 * @Brief: nordic 1M Initialization Table
 */
static void tbl_rf_private_1m(void)
 {
	analog_write(0x8f, 0x2b);
	analog_write(0x93, 0x38);
	analog_write(0x9e, 0x56);
	analog_write(0xa3, 0xf0);	//********[7:6] disable gauflt [5] LUT 2M or 1M
	analog_write(0xaa, 0x26);

	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x402, 0x26);	// 8-byte pre-amble
	WRITE_REG8(0x42b, 0xf1);	// access code: 1
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4] 0x12
	WRITE_REG8(0x428, 0x80);	// number fo sync: bit[6:4] 0x12
	WRITE_REG8(0x422, 0x00);	// threshold 0x00
	WRITE_REG8(0x420, 0x1f);	// threshold  31/32
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x464, 0x07);

	WRITE_REG8(0x46e, 0x00);
	WRITE_REG8(0x404, 0xda);	// head_mode/crc_mode: normal c0; 0xf7 for RX shockburst
	WRITE_REG8(0xf02, 0x64);
	WRITE_REG8(0xf03, 0x36);	// bit3: crc2_en; normal 1e
	WRITE_REG8(0x4ca, 0xa0);
	WRITE_REG8(0x04cb, 0x8c);

	WRITE_REG8(0x42c, 0xff); //baseband receive Max length
	WRITE_REG8(0x43b, 0xfc);//select timestamp
 }
/**
 * @Brief: nordic 2M Initialization Table
 */
static void TblRFNordic2M_write(void)
 {
	analog_write(0x8f, 0x32);
	analog_write(0x93, 0x50);
	analog_write(0x9e, 0xad);
	analog_write(0xa3, 0x10);	//close gaussian filter
	analog_write(0xaa, 0x2e);

	WRITE_REG8(0x400, 0x0f);	// New 2M mode
	WRITE_REG8(0x402, 0x8c);  // 8-byte pre-amble
	WRITE_REG8(0x405, 0x04); // access code length
	WRITE_REG8(0x42b, 0xf1);	// access code: 1
	WRITE_REG8(0x424, 0x12);	// number fo sync: bit[6:4]
	WRITE_REG8(0x428, 0x80);	// access code:
	WRITE_REG8(0x422, 0x00);	// threshold
	WRITE_REG8(0x420, 0x1f);	// sync threshold: 1e (4); 26 (5)
	WRITE_REG8(0x421, 0x04);	// no avg 0x04 -> 0x00
	WRITE_REG8(0x464, 0x07);

	WRITE_REG8(0x46e, 0x00);
	WRITE_REG8(0x404, 0xca);	// head_mode/crc_mode: normal c5
	WRITE_REG8(0xf02, 0x64);
	WRITE_REG8(0xf03, 0x36);	// bit3: crc2_en; normal 1e
 	WRITE_REG8(0x4ca, 0xa0);
 	WRITE_REG8(0x4cb, 0x8c);

 	WRITE_REG8(0x42c, 0xff); //baseband receive Max length
	WRITE_REG8(0x43b, 0xfc);//select timestamp
 }

/**
 * @Brief: nordic 1M Initialization Table
 */
static void TblRFPrivate250K_write(void)
 {
	analog_write(0x8f, 0x2b);
	analog_write(0x93, 0x38);
	analog_write(0x9e, 0x56);
	analog_write(0xa3, 0xf0);
	analog_write(0xaa, 0x26);


	WRITE_REG8(0x402, 0x8b);
	WRITE_REG8(0x424, 0x12);
	WRITE_REG8(0x422, 0x00);
	WRITE_REG8(0x420, 0x1f);
	WRITE_REG8(0x421, 0x04);

	WRITE_REG8(0x404, 0xda);
	WRITE_REG8(0x403, 0x02);
 	WRITE_REG8(0xf02, 0x44);
 	WRITE_REG8(0xf03, 0x36);
 	WRITE_REG8(0x4ca,0x80);
 	WRITE_REG8(0x43b, 0x8c);
 	WRITE_REG8(0x4cd, 0xe4);
 }
/**
 * @Brief: nordic 2M Initialization Table
 */
static void TblRFPrivate500K_write(void)
  {
	analog_write(0x8f, 0x2b);
	analog_write(0x93, 0x38);
	analog_write(0x9e, 0x56);
	analog_write(0xa3, 0xf0);
	analog_write(0xaa, 0x26);


	WRITE_REG8(0x402, 0x8b);
	WRITE_REG8(0x424, 0x12);
	WRITE_REG8(0x422, 0x00);
	WRITE_REG8(0x420, 0x1f);
	WRITE_REG8(0x421, 0x04);

	WRITE_REG8(0x404, 0xda);
	WRITE_REG8(0x403, 0x01);
  	WRITE_REG8(0xf02, 0x44);
  	WRITE_REG8(0xf03, 0x36);
  	WRITE_REG8(0x4ca,0x80);
  	WRITE_REG8(0x43b, 0x8c);
  	WRITE_REG8(0x4cd, 0xe4);
  }

/**
 * @Brief: BLE250K Initialization Table
 */
static void TblRFBLE250K_write(void)
 {
	analog_write(0x8f, 0x38);
	analog_write(0x93, 0x50);
	analog_write(0x9e, 0xad);
	analog_write(0xa3, 0x10);
	analog_write(0xaa, 0x2e);

	WRITE_REG8(0x400, 0x0f);
	WRITE_REG8(0x402, 0x2b);
	WRITE_REG8(0x42b, 0xf1);// access code: 1
	WRITE_REG8(0x424, 0x12);// number fo sync: bit[6:4]
	WRITE_REG8(0x428, 0x01);
	WRITE_REG8(0x422, 0x00); // threshold
	WRITE_REG8(0x420, 0x1f); // sync threshold: 1e (4); 26 (5)
	WRITE_REG8(0x421, 0x04); // no avg
	WRITE_REG8(0x464, 0x07);

	WRITE_REG8(0x404, 0xd5);// head_mode/crc_mode: normal c5
	WRITE_REG8(0x403, 0x02);

	WRITE_REG8(0xf02, 0x65);
	WRITE_REG8(0xf03, 0x1e);
	WRITE_REG8(0x4ca, 0x80);
	WRITE_REG8(0x4cb, 0x06);

	WRITE_REG8(0x42c, 0x80);//baseband receive Max length
	WRITE_REG8(0x43b, 0x9c);//select timestamp
	WRITE_REG8(0x4cd, 0xe4);//select timestamp
 }

/**
 * @Brief: BLE500K Initialization Table
 */
static void TblRFBLE500K_write(void)
 {
	analog_write(0x8f, 0x38);
	analog_write(0x93, 0x50);
	analog_write(0x9e, 0xad);
	analog_write(0xa3, 0x10);
	analog_write(0xaa, 0x2e);

	WRITE_REG8(0x400, 0x0f);
	WRITE_REG8(0x402, 0x2b);
	WRITE_REG8(0x42b, 0xf1);// access code: 1
	WRITE_REG8(0x424, 0x12);// number fo sync: bit[6:4]
	WRITE_REG8(0x428, 0x01);
	WRITE_REG8(0x422, 0x00); // threshold
	WRITE_REG8(0x420, 0x1f); // sync threshold: 1e (4); 26 (5)
	WRITE_REG8(0x421, 0x04); // no avg
	WRITE_REG8(0x464, 0x07);

	WRITE_REG8(0x404, 0xd5);// head_mode/crc_mode: normal c5
	WRITE_REG8(0x403, 0x01);

	WRITE_REG8(0xf02, 0x65);
	WRITE_REG8(0xf03, 0x1e);
	WRITE_REG8(0x4ca, 0x80);
	WRITE_REG8(0x4cb, 0x06);

	WRITE_REG8(0x42c, 0x80);//baseband receive Max length
	WRITE_REG8(0x43b, 0x9c); //select timestamp
	WRITE_REG8(0x4cd, 0xe4);//select timestamp
 }
static void agc_tbl_write(void)
{
	WRITE_REG8(0x489, 0x1c);// 8-byte pre-amble
	WRITE_REG8(0x488, 0x18); // access code: 1
	WRITE_REG8(0x487, 0x2c); // number fo sync: bit[6:4]
	WRITE_REG8(0x486, 0x3c);
	WRITE_REG8(0x485, 0x38); // threshold
	WRITE_REG8(0x484, 0x30); // sync threshold: 1e (4); 26 (5)
	WRITE_REG8(0x483, 0x23); // no avg
	WRITE_REG8(0x482, 0x23);
	WRITE_REG8(0x481, 0x23);// head_mode/crc_mode: normal c5
	WRITE_REG8(0x480, 0x23);
	WRITE_REG8(0x499, 0x3f);
	WRITE_REG8(0x498, 0x39);
	WRITE_REG8(0x497, 0x36);
	WRITE_REG8(0x496, 0x30);
	WRITE_REG8(0x495, 0x2a);//baseband receive Max length
	WRITE_REG8(0x494, 0x24); //select timestamp
	WRITE_REG8(0x493, 0x20);
	WRITE_REG8(0x492, 0x20);
	WRITE_REG8(0x491, 0x20);
	WRITE_REG8(0x490, 0x20);
}

const char tbl_rf_power[] = {
	//a2    04    a7    8d

	0x25,	0x92,	0xd9,	0x62,	   //7.9
	0x25, 	0x82, 	0xd9, 	0x62,     //7dbm
	0x25,	0xb2,	0xe9,	0x62,	   //6.3
	0x19,	0xa2,	0xe9,	0x62,	   //4.9
	0x12,	0x92,	0xe9,	0x62,	   //3.3
	0x0a,	0x92,	0xe9,	0x62,	   //1.6
	0x08,	0x8a,	0xe9,	0x62,	   //0
	0x05,	0x9a,	0xe9,	0x62,	   //-1.5
	0x04,	0xa2,	0xe9,	0x62,	   //-3.1
	0x03,	0xba,	0xe9,	0x62,	   //-5
	0x02,	0xa2,	0xd9,	0x62,	   //-7.3
	0x02,	0x82,	0xd9,	0x62,	   //-9.6
	0x02,	0xaa,	0xe9,	0x62,	   //-11.5
	0x01,	0x9a,	0xd9,	0x62,	   //-13.3
	0x01,	0xba,	0xe9,	0x62,	   //-16
	0x01,	0xa2,	0xe9,	0x62,	   //-17.8
	0x00,	0x92,	0xd9,	0x62,	   //-19.5
};
/**
 * @brief   This function serves to set gain in manual mode.
 * @param   none.
 * @return  none.
 */
void rf_set_manual_max_gain (void)
{
	//disable Agc setting
	 WRITE_REG8(0x430,0x17);
	 WRITE_REG8(0x43d,0xfd);
	 WRITE_REG8(0x438,0x37);

	// MaxGain setting
	 WRITE_REG8(0x433,0x00);
	 WRITE_REG8(0x434,0x01);
	 WRITE_REG8(0x43a,0x77);
	 WRITE_REG8(0x43e,0x89);
	 WRITE_REG8(0x4cd,0x66);
	 WRITE_REG8(0x4c0,0x81);
}

/**
 * @brief   This function serves to set gain in auto mode.
 * @param   none.
 * @return  none.
 */
void rf_set_agc (void)
{
	//disable Maxgain setting
	 WRITE_REG8(0x433,0x01);
	 WRITE_REG8(0x434,0x21);
	 WRITE_REG8(0x43a,0x22);
	 WRITE_REG8(0x43e,0x20);

	//enable agc
	 WRITE_REG8(0x430,0x12);
	 WRITE_REG8(0x43d,0xb1);
	 WRITE_REG8(0x438,0xb7);

	//for agc setting
	 WRITE_REG8(0x437,0xda);
	 WRITE_REG8(0x46e,0x00);
	 analog_write(0xaa,(analog_read(0xaa)&0x7f));
}

/**
*	@brief	 This function is to update TP(two point),this value will affect
*			 RF performance
*	@param[in]	tp0  	    Tp value for lower frequency
*							If you set a value outside the range, you will be set to fail.
*	@param[in]	tp1  	    Tp value for higher frequency
*							If you set a value outside the range, you will be set to fail.
*	@return	 	0 :set success;
*              -1 :set failed
*/
void rf_set_tp (unsigned char tp0, unsigned char tp1)
{
	 rf_tp_base = tp0;
	 rf_tp_gain = TP_GET_GAIN(tp0, tp1);
}


/**
*	@brief	  	This function servers to swap 8 byte .
*   @param      original - The quantity need to swap.
*	@return	 	rf_ed:0x00~0xff
*/
static unsigned char bit_swap8(unsigned char original)
{
    unsigned char ret = 0;
    int i = 0;
    for (i = 0; i < 8; i++) {
        if (original & 0x01) {
            ret |= 0x01;
        }
        else {
            ret &= 0xfe;
        }
        if (i == 7) {
            break;
        }
        ret <<= 1;
        original >>= 1;
    }
    return ret;
}

/**
*	@brief	  	This function servers to set multi byte write.
*   @param      reg_start - register start.
*   @param      buf - store bytes, which need to be write.
*   @param      len - the length of byte.
*	@return	 	rf_ed:0x00~0xff
*/
static void multi_byte_reg_write(unsigned int reg_start, unsigned char *buf, int len)
{
    int i = 0;
    for (i = 0; i < len; i++,reg_start++) {
        WRITE_REG8(reg_start, buf[i]);
    }
}
/**
*	@brief	  	This function servers to set multi byte read.
*   @param      reg_start - register start.
*   @param      buf - store bytes, which need to be read.
*   @param      len - the length of byte.
*	@return	 	rf_ed:0x00~0xff
*/
static void multi_byte_reg_read(unsigned int reg_start, unsigned char *buf, int len)
{
    int i = 0;
    for (i = 0; i < len; i++,reg_start++) {
        buf[i] = READ_REG8(reg_start);
    }
}

/**
*	@brief	  	this function is to set access code.
*	@param[in]	pipe  	index number for access_code channel.Only one pipe 1 can be use.
*	@param[in]	addr    the access code address.
*	@return	 	none
*/

void rf_set_acc_code_pipe(unsigned char pipe_id, const unsigned char *addr)
{
    unsigned char temp[5];
    unsigned char acc_len = READ_REG8(0x405) & 0x07;
    unsigned char i = 0;
    for (i = 0; i < acc_len; i++) {
        temp[i] = bit_swap8(addr[i]);
    }
        multi_byte_reg_write(0x800408, temp, acc_len);

}


/**
*	@brief	  	this function is to set access code.
*	@param[in]	pipe  	index number for access_code channel.
*	@param[in]	addr    the access code address.
*	@return	 	none
*/
void rf_get_acc_code_pipe(unsigned char pipe_id, unsigned char *addr)
{
    unsigned char acc_len = READ_REG8(0x405) & 0x07;
    unsigned char i = 0;
	multi_byte_reg_read(0x800408 , addr, acc_len);

    for (i = 0; i < acc_len; i++) {
        addr[i] = bit_swap8(addr[i]);
    }
}

/**
*	@brief     This function serves to initiate information of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
//////////////////////////////////////////////////////////////////////////////////
void rf_mode_init (void)
{
	tbl_rf_init_write();
	reg_dma_chn_en |= FLD_DMA_CHN_RF_RX  | FLD_DMA_CHN_RF_TX;
}

/**
*	@brief     This function serves to  set ble_1M  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_1M_mode(void)
{
	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	tbl_rf_ble_1m_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set ble_2M  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_2M_mode(void)
{
	rf_tp_base = TP_2M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_2M_G0, TP_2M_G1);
	tbl_rf_ble_2m_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set ble_250K  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_250K_mode(void)
{
	rf_tp_base = TP_2M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_2M_G0, TP_2M_G1);
	TblRFBLE250K_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set ble_500K  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_500K_mode(void)
{

	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	TblRFBLE500K_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set ble_1M_NO_PN  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_1M_NO_PN_mode(void)
{
	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	tbl_rf_ble_1m_no_pn_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set ble_2M_NO_PN  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_ble_2M_NO_PN_mode(void)
{
	rf_tp_base = TP_2M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_2M_G0, TP_2M_G1);
	tbl_rf_2m_no_pn_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set pri_1M  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_pri_1M_mode(void)
{
	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	tbl_rf_private_1m();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set pri_2M  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_pri_2M_mode(void)
{
	rf_tp_base = TP_2M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_2M_G0, TP_2M_G1);
	TblRFNordic2M_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}

/**
*	@brief     This function serves to set pri_250K  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_pri_250K_mode(void)
{
	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	TblRFPrivate250K_write();
	agc_tbl_write();
	rf_set_manual_max_gain();

}

/**
*	@brief     This function serves to set pri_500K  mode of RF
*	@param[in] rf_mode  -  mode of RF
*	@return	   none.
*/
void rf_set_pri_500K_mode(void)
{
	rf_tp_base = TP_1M_G0;
	rf_tp_gain = TP_GET_GAIN(TP_1M_G0, TP_1M_G1);
	TblRFPrivate500K_write();
	agc_tbl_write();
	rf_set_manual_max_gain();
}



/**
 * @brief   This function serves to set RF power level index.
 * @param   RF_PowerTypeDef - the RF power types.
 * @return  none.
 */


void rf_set_power_level_index (RF_TxPowerTypeDef level)
{

	if (level + 1 > (sizeof (tbl_rf_power)>>2)) {
		level = (sizeof (tbl_rf_power)>>2) - 1;
	}

	unsigned char *p = (unsigned char*)(tbl_rf_power + level * 4);
	analog_write (0xa2, *p++);

	analog_write(0xa3,analog_read(0xa3)&0xef); //ana_0xa3<4> PA ramp enable
	analog_write(0xa3,analog_read(0xa3)|0x10);

	analog_write (0x04, *p++);
	analog_write (0xa7, *p++);
	analog_write (0x8d, *p++);
}


/**
 * @brief   This function serves to set gain in auto mode.
 * @param   chn  - set tp gain for the specified channel
 * @return  none.
 */

void rf_set_tp_gain (char chn)
{
	 analog_write (TX_GAIN, rf_tp_base - ((chn * rf_tp_gain + 128) >> 8));
}

/**
 * @brief   This function serves to set RF channel.
 * @param   chn -the RF channel
 * @param   set - to set RF_SET_TX_MANAUL or not
 * @return  none.
 */

void rf_set_channel (signed char chn, unsigned short set)
{
	// turn on LDO and baseband PLL
	analog_write (0x06, 0x00);
	WRITE_REG8 (0x800f16, 0x29);

	WRITE_REG8 (0x800428, 0x80);	// rx disable
	if ( set & RF_SET_TX_MANAUL )
	{
        WRITE_REG8 (0x800f02, RF_TRX_OFF_MANUAL);  // reset tx/rx state machine
    }
    else
    {
    	WRITE_REG8 (0x800f02, 0x44);
    }

	if (set & RF_CHN_TABLE)
	{
		chn = rf_chn[chn];
	}
	WRITE_REG16 (0x8004d6, 2400 + chn);	// {intg_N}
	analog_write (TX_GAIN, rf_tp_base - ((chn * rf_tp_gain + 128) >> 8));
}

/**
 * @brief   This function serves to set RF_BLE channel.
 * @param   chn -the RF channel
 * @return  none.
 */
void rf_set_ble_channel (signed char chn)
{
	WRITE_REG8 (0x80040d, chn);

	if (chn < 11)
    	chn += 2;
    else if (chn < 37)
    	chn += 3;
    else if (chn == 37)
    	chn = 1;
    else if (chn == 38)
    	chn = 13;
    else
    	chn = 40;

    chn = chn << 1;

	// turn on LDO and baseband PLL
	analog_write (0x06, 0x00);
	WRITE_REG8 (0x800f16, 0x29);

	WRITE_REG8 (0x800428, 0x80);	// rx disable
	WRITE_REG8 (0x800f02, 0x45);	// reset tx/rx state machine

	WRITE_REG16 (0x8004d6, 2400 + chn);	// {intg_N}
    analog_write (TX_GAIN, rf_tp_base - ((chn * rf_tp_gain + 128) >> 8));
}




/**
*	@brief	  	This function is to set rx buffer
*
*	@param[out]	RF_RxAddr  	Pointer for Rx buffer in RAM(Generally it��s starting
*							address of an array.Should be 4-byte aligned)
*	@param[in]	size   		Rx buffer size (It��s an integral multiple of 16)
*	@param[in]	PingpongEn 	Enable/Disable Ping-Pong buffer 1��Enable 0��Disable
*							Note:
*							When ��PingpongEn�� is set as 0, received RF data will
*							be stored in RAM pointed by �� RF_RxAddr��.
*							When ��PingpongEn�� is set as 1, received RF data will
*							be stored in buffer0 and buffer1 successively.
*							The RAM size reserved for received RF data should be
*							double of ��Size��.
*
*	@return	 	none
*/
void  rf_set_rx_buff(unsigned char *  RF_RxAddr, int size, unsigned char  PingpongEn)
{
    unsigned char mode;

	mode = PingpongEn ? 0x03 : 0x01;
	reg_dma2_addr = (unsigned short)((unsigned int)RF_RxAddr);
	reg_dma2_size = size>>4;
	reg_dma2_mode = mode;
}

/**
*	@brief	  	This function serves to start Tx of ble_mode.
*	@param[in]	addr   Tx packet address in RAM. Should be 4-byte aligned.
*	@param[in]	tick  Tick value of system timer. It determines when to
*						  	  start ble mode and send packet.
*	@return	 	none
*/
void rf_start_btx (void* addr, unsigned int tick)
{
	WRITE_REG32(0x800f18, tick);						// Setting schedule trigger time
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode

	WRITE_REG16 (0x80050c, (unsigned short)((unsigned int)addr));
	WRITE_REG8 (0x800f00, 0x81);						// ble tx
}
/**
*	@brief	  	This function serves to start Tx of ble_mode.
*	@param[in]	addr   Tx packet address in RAM. Should be 4-byte aligned.
*	@param[in]	tick  Tick value of system timer. It determines when to
*						  	  start ble mode and send packet.
*	@return	 	none
*/
void rf_start_brx(void* addr, unsigned int tick)
{
	WRITE_REG32(0x800f28, 0x0fffffff);					// first timeout
	WRITE_REG32(0x800f18, tick);						// Setting schedule trigger time
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode

	WRITE_REG16(0x80050c,(unsigned short)((unsigned int)addr));
	WRITE_REG8(0x800f00, 0x82);						// ble rx
}

/**
*	@brief	  	This function serves to start Tx.
*	@param[in]	addr   Tx packet address in RAM. Should be 4-byte aligned.
*	@param[in]	tick  Tick value of system timer.
*	@return	 	none
*/
void rf_start_stx  (void* addr, unsigned int tick)
{
	WRITE_REG32(0x800f18, tick);						// Setting schedule trigger time
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode

	WRITE_REG16 (0x80050c, (unsigned short)((unsigned int)addr));
	WRITE_REG8 (0x800f00, 0x85);	// single TX
}
/**
*	@brief	  	This function serves to start Rx.
*	@param[in]	tick  Tick value of system timer.
*	@return	 	none
*/
void rf_start_srx  (unsigned int tick)
{
	WRITE_REG32 (0x800f28, 0x0fffffff);					// first timeout
	WRITE_REG32(0x800f18, tick);
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode
	WRITE_REG16 (0x800f00, 0x3f86);						// srx
}
/**
*	@brief	  	This function serves to start stx2rx mode of auto_mode.
*				In this mode, a packet is sent first,RF module waits for 10us,
*				stays in Rx status until data is received or timeout expires,
*				then exits this mode.Timeout duration is set by the parameter
*				��timeout_us��.The address to store received data is set by the
*				function ��RF_RxBufferSet��.
*
*	@param[in]	addr  Tx packet address in RAM. Should be 4-byte aligned.
*	@param[in]	tick   	Tick value of system timer. It determines when
*								to start StxToRx mode and send packet.
*	@param[in]	timeout_us  Unit is us. It indicates timeout duration in
*							 	Rx status.Max value: 0xfff (4095)
*
*	@return	 	none
*/
void rf_start_stx2rx  (void* addr, unsigned int tick, unsigned int timeout_us)
{
	WRITE_REG32(0x800f18, tick);						// Setting schedule trigger time
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode

	WRITE_REG16 (0x80050c, (unsigned short)((unsigned int)addr));
	WRITE_REG8  (0x800f00, 0x87);                       // single tx2rx
}

/**
*	@brief	  	This function serves to start srx2tx mode of auto_mode.
*				In this mode,RF module stays in Rx status until a packet is
*				received or it fails to receive packetwhen timeout expires.
*				If a packet is received within the timeout duration, RF module
*				will wait for 10us,send a packet, and then exit this mode.
*				If it fails to receive packet when timeout expires, RF module
*				will directly exit this mode.Timeout duration is set by the
*				parameter "timeout_us".	The address to store received data is set
*				by the function ��RF_RxBufferSet��.
*
*	@param[in]	addr 	Tx packet address in RAM. Should be 4-byte aligned.
*	@param[in]	tick   Tick value of system timer. It determines when to
*								start SrxToTx mode.
*	@param[in]	timeout_us  Unit is us. It indicates timeout duration in Rx status.
*								Max value: 0xffffff (16777215)
*
*	@return	 	none
*/
void rf_start_srx2tx  (void* addr, unsigned int tick,  unsigned int timeout_us)
{
	WRITE_REG32 (0x800f28, 0x0fffffff);					// first timeout
	WRITE_REG32(0x800f18, tick);						// Setting schedule trigger time
    WRITE_REG8(0x800f16, READ_REG8(0x800f16) | 0x04);	// Enable cmd_schedule mode

	WRITE_REG16 (0x80050c, (unsigned short)((unsigned int)addr));
	WRITE_REG16 (0x800f00, 0x3f88);						// single rx2tx
}


/**
*	@brief	  	This function serves to set ack.
*	@param[in]  none.
*	@return	 	none.
*/
void rf_set_ack_packet  (void* addr)
{
	WRITE_REG16 (0x80050c, (unsigned short)((unsigned int)addr));
}
/**
*	@brief	  	This function serves to set RF Tx packet.
*	@param[in]	*addr - the address RF to send packet.
*	@return	 	none.
*/
void rf_tx_pkt(unsigned char *rf_txaddr)
{
	WRITE_REG8(0x50f,0x80); //dma mode
    WRITE_REG16 (0x50c, (unsigned short)((unsigned int)rf_txaddr));
    WRITE_REG8 (0x524, 0x08); // dma packet ready for transfer
}


/**
*	@brief	  	This function serves to judge RF Tx/Rx state.
*	@param[in]	rf_status - Tx/Rx status.
*	@param[in]	rf_channel - RF channel.
*	@return	 	failed -1,else success.
*/
int rf_set_trx_state(RF_StatusTypeDef rf_status, signed char rf_channel)
{
    int err = 0;

    WRITE_REG8(0x4d6, rf_channel+2400);
    if (rf_status == RF_MODE_TX) {
        WRITE_REG8(0xf02, 0x45);  //reset tx_en in manual mode
        WRITE_REG8(0xf02, 0x55);  //tx_en
        WRITE_REG8(0x428, READ_REG8(0x428) & 0xfe);  //rx disable
        RF_TRxState = RF_MODE_TX;
    }
    else if (rf_status == RF_MODE_RX) {

    	WRITE_REG8(0xf02, 0x45);
    	delay_us(5);
        WRITE_REG8(0xf02, 0x65);
        WRITE_REG8(0x428, READ_REG8(0x428) | 0x01);  //rx enable
        RF_TRxState = RF_MODE_RX;
    }
    else if (rf_status == RF_MODE_AUTO) {
        WRITE_REG8(0xf00,0x80); //stop cmd
        WRITE_REG8(0xf16, 0x29); // reg0xf16 pll_en_man and tx_en_dly_en  enable
        WRITE_REG8(0x428, READ_REG8(0x428) & 0xfe);  //rx disable
        WRITE_REG8(0xf02, READ_REG8(0xf02) & 0xcf);  //reg0xf02 disable rx_en_man and tx_en_man
        RF_TRxState = RF_MODE_AUTO;
    }
    else {
        err = -1;
    }

    analog_write (TX_GAIN, rf_tp_base - ((rf_channel * rf_tp_gain + 128) >> 8));
    return  err;
}
/**
*	@brief	  	This function serves to get RF status.
*	@param[in]	none.
*	@return	 	RF Rx/Tx status.
*/
RF_StatusTypeDef rf_get_trx_state(void)
{
    return RF_TRxState;
}


/**
*	@brief	  	This function serves to set TXmode and send data.
*	@param[in]	* addr - buffer.
*	@param[in]	tick - trigger time.
*	@param[in]	mode - set TX mode
*	@return	 	none.
*/
void rf_schedule(void* addr,  unsigned int tick,  unsigned int mode){

	WRITE_REG8(0xf02, 0x45 | BIT(4));        // Manual TX enable
	WRITE_REG32(0xf04, 0);                          // tx wail & settle time: 0
    WRITE_REG32(0xf18, tick);						// Setting schedule trigger time
	WRITE_REG8(0xf16, 0x2d);	// Enable cmd_schedule mode
    WRITE_REG16(0x80050c, (unsigned short)((unsigned int)addr));
    WRITE_REG8(0xf00, mode);	// single TX
}


/**
*	@brief	  	This function serves to save salve  state .
*	@return	 	failed -1,else success.
*/
void rf_slave_save_snnesn (){
		rf_nesn = ((REG_ADDR8(0xf22) & BIT(0)) << 4) | ((REG_ADDR8(0xf23) & BIT(4)) << 1);
}
/**
*	@brief	  	This function serves to save  slave state .
*	@return	 	failed -1,else success.
*/
void rf_slave_restore_snnesn (){
		reg_timeout_nesn = (reg_timeout_nesn & ~(FLD_BRX_SN|FLD_BRX_NESN)) | rf_nesn;
}


/**
*	@brief	  	This function serves to save master state .
*	@return	 	failed -1,else success.
*/
void rf_master_save_snnesn (){
		rf_nesn = ((REG_ADDR8(0xf22) & BIT(0)) << 6) | ((REG_ADDR8(0xf23) & BIT(4)) << 3);
}
/**
*	@brief	  	This function serves to restore  master state .
*	@return	 	failed -1,else success.
*/
void rf_master_restore_snnesn (){
		reg_timeout_nesn = (reg_timeout_nesn & ~(FLD_BTX_SN|FLD_BTX_NESN)) | rf_nesn;
}




