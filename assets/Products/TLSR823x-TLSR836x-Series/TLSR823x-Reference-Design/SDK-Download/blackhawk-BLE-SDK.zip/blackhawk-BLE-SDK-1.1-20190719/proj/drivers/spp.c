
#include "../tl_common.h"

#include "../../proj/drivers/spp.h"

#define SPP_TX_BUF_SIZE		(24)		//  the first 4 byte is len, so the total len is 24
#define SPP_TX_BUF_CNT		4
#define SPP_RX_BUF_SIZE		(24)		//  the first 4 byte is len, so the total len is 24
#define SPP_RX_BUF_CNT		4
STATIC_ASSERT_INT_DIV(SPP_TX_BUF_SIZE, 4);
STATIC_ASSERT_INT_DIV(SPP_RX_BUF_SIZE, 4);
STATIC_ASSERT_POW2(SPP_TX_BUF_CNT);
STATIC_ASSERT_POW2(SPP_RX_BUF_CNT);
STATIC_ASSERT(UART_HALFDUP_ARBI == UART_CRC_ENABLE);	// ???	
STATIC_ASSERT_IMPLIES(UART_HALFDUP_ARBI || UART_CRC_ENABLE, UART_ENABLE);	// ???	
///////////////////////////////////////////////////////////////////////////
#if(UART_HALFDUP_ARBI)				// half duplex arbitration
static u8 sppState;					//  0:  idle,   1: sendingState,   2:  receivingState
static u8 sppPendingState;			//  0:  idle,   1: sendingState,   2:  receivingState
#endif

#define SPP_TX_BUF_MASK		(SPP_TX_BUF_CNT-1)
#define SPP_RX_BUF_MASK		(SPP_RX_BUF_CNT-1)

static u8 spp_tx_wr_idx, spp_tx_rd_idx;
static u8 spp_tx_buf[SPP_TX_BUF_CNT][SPP_TX_BUF_SIZE] _attribute_aligned_(4);

static void sppTxPush_i(u8* p, u8 *d, u8 len){
	memcpy(p+(UART_SIMU?1:4), d, len); 
	if(UART_CRC_ENABLE){
		int crc = blt_packet_crc24(d, len, 0);
		memcpy(p+(UART_SIMU?1:4)+len, &crc, 3); 
	}
	p[0] = len + (UART_CRC_ENABLE?3:0);
}
int sppTxPush(u8 *d, u8 len){
	if(((u8)(spp_tx_wr_idx - spp_tx_rd_idx)) < SPP_TX_BUF_CNT && len <= (SPP_TX_BUF_SIZE-4)){
		u8 *p = &spp_tx_buf[spp_tx_wr_idx & SPP_TX_BUF_MASK]; ++spp_tx_wr_idx;
		sppTxPush_i(p, d, len);
		return 1;
	}
	return 0;
}
#if(UART_SIMU)
static void sppTxPushAndSend(u8 *d, u8 len){		//  send immediately
	u8 p[SPP_TX_BUF_SIZE];
	sppTxPush_i(p, d, len);
	uartTx(p+1, p[0]);
}
void sppSyncSendAck(u16 index){
	u8 buf[3];
	buf[0] = SPP_CMD_ACK;
	buf[1] = index & 0xff;
	buf[2] = index >> 8;
#if(UART_SIMU)
	sppTxPushAndSend(&buf, 3);
#else
	sppTxPush(&buf, 3);
#endif
}
static void sppSyncSendStart(){
	u8 buf = 0x55;
#if(UART_SIMU)
	sppTxPushAndSend(&buf, 1);
#else
	sppTxPush(&buf, 1);
#endif
}
static void sppSyncSendEnd(){
	u8 buf = 0xaa;
#if(UART_SIMU)
	sppTxPushAndSend(&buf, 1);
#else
	sppTxPush(&buf, 1);
#endif
}
void sppSyncSendVersion(u8 v){
	u8 buf[2] = {SPP_CMD_VER, v};
	#if(UART_SIMU)
	sppTxPushAndSend(buf, 2);		 // send immediately is better
	#else
	sppTxPush(buf, 2);
	#endif
}
void sppSyncSendOtaStatus(u8 v){
	u8 buf[2] = {SPP_CMD_UPD_STA, v};
	#if(UART_SIMU)
	sppTxPushAndSend(buf, 2);		 // send immediately is better
	#else
	sppTxPush(buf, 2);
	#endif
}
#endif

#if(UART_HALFDUP_ARBI && UART_SIMU)
static u32 sppStartTime;
#endif
static u8 sppSending;
static void sppTx(){
	if(((u8)(spp_tx_wr_idx - spp_tx_rd_idx)) > 0){
		#if(UART_HALFDUP_ARBI && UART_SIMU)
		if(!sppState && clock_time_exceed(sppStartTime, 40*1000)){		// sppState must in sending state, if UART_HALFDUP_ARBI
			sppStartTime = clock_time();
			sppPendingState = 1;

			sppSyncSendStart();
			return;
		}
		if(1 != sppState) return;
		#endif
		u8 *p = &spp_tx_buf[spp_tx_rd_idx & SPP_TX_BUF_MASK]; ++spp_tx_rd_idx;

		#if(UART_HALFDUP_ARBI && UART_SIMU)
		sppStartTime = clock_time();
		#endif
		
		if(UART_ENABLE){
			if(UART_SIMU){
				uartTx(p+1, p[0]); 
			}else{
				uart_dma_send(p);
				sppSending = 1;
			}
		}
	}
	#if(UART_HALFDUP_ARBI && UART_SIMU)
	else if(1 == sppState && clock_time_exceed(sppStartTime, 200*1000)){
		sppState = sppPendingState = 0;
		sppSyncSendEnd();
	}
	//  receiving timeout	
	if(2 == sppState && clock_time_exceed(sppStartTime, 300*1000)){
		sppState = sppPendingState = 0;
	}
	#endif

}

static u8 spp_rx_wr_idx, spp_rx_rd_idx;
static u8 spp_rx_buf[SPP_RX_BUF_CNT][SPP_RX_BUF_SIZE] _attribute_aligned_(4);
u8  *sppRxPush(u8 *d, u8 len){
	#if(UART_HALFDUP_ARBI && UART_SIMU)
	sppStartTime = clock_time();
	if(SPP_CMD_ACK == d[0]){					// ack
		sppState = sppPendingState;  sppPendingState = 0;
		return 0;
	}else if((SPP_CMD_START == d[0] && 1 != sppState) || SPP_CMD_END == d[0]){
		sppSyncSendAck(0);
		if(SPP_CMD_START == d[0]){
			sppState = 2;			//  receiving state
		}else{
			sppState = 0;			// idle state
		}
		return 0;
	}
	if(1 != sppState){
		sppState = 2;
	}
	#endif
	if(((u8)(spp_rx_wr_idx - spp_rx_rd_idx)) < SPP_RX_BUF_CNT && len <= (SPP_RX_BUF_SIZE-(UART_CRC_ENABLE?1:4))){
		u8 *p = &spp_rx_buf[spp_rx_wr_idx & SPP_RX_BUF_MASK]; ++spp_rx_wr_idx;
		p[0] = len;
		memcpy(p+(UART_SIMU?1:4), d, len); 
		return &spp_rx_buf[spp_rx_wr_idx & SPP_RX_BUF_MASK];
	}
	return 0;
}
#if(!UART_SIMU)
u8 *sppRxPushDma(){
	if(((u8)(spp_rx_wr_idx - spp_rx_rd_idx)) < SPP_RX_BUF_CNT){
		 ++spp_rx_wr_idx;
		 return &spp_rx_buf[spp_rx_wr_idx & SPP_RX_BUF_MASK];
	}
	return 0;
}
#endif
static void sppRx(){
	if(((u8)(spp_rx_wr_idx - spp_rx_rd_idx)) > 0){
		u8 *p = &spp_rx_buf[spp_rx_rd_idx & SPP_RX_BUF_MASK];
		++spp_rx_rd_idx;
		spp_rx_cb(p+(UART_SIMU?1:4), p[0]);
	}
}

void sppReset(){
	spp_tx_wr_idx = spp_tx_rd_idx = spp_rx_wr_idx = spp_rx_rd_idx = 0;
	if(UART_ENABLE && !UART_SIMU){
		sppSending = 0;
	}
}

int sppIsIdle(){
	return (!sppSending) && (spp_tx_wr_idx == spp_tx_rd_idx) && (spp_rx_wr_idx == spp_rx_rd_idx);
}

void sppInit(u32 baudrate){
	if(UART_ENABLE && !UART_SIMU){
		uart_init_baudrate(baudrate, CLOCK_RUN_CLOCK_HZ, &spp_rx_buf[0], SPP_RX_BUF_SIZE);
	}
	if(baudrate){
		BM_SET(reg_dma_chn_irq_msk, FLD_DMA_CHN_UART_RX);
		BM_SET(reg_irq_mask, FLD_IRQ_DMA_EN);
	}else{
		BM_CLR(reg_dma_chn_irq_msk, FLD_DMA_CHN_UART_RX);
		BM_CLR(reg_irq_mask, FLD_IRQ_DMA_EN);
	}
}
void sppCheck(){
	if(UART_ENABLE && !UART_SIMU){	// of couse not  UART_HALFDUP_ARBI
		if(reg_uart_status1 & BIT(0)){
			sppSending = 0;
		}
	}
	if(UART_SIMU || !sppSending){
		sppTx();
	}
	sppRx();
}

