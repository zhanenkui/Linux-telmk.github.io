
#pragma once

int sppTxPush(u8 *d, u8 len);
u8 *sppRxPush(u8 *d, u8 len);
u8 *sppRxPushDma();
void sppReset();
int uartIsIdle();
void sppInit(u32 baudrate);
void sppCheck();

#define SPP_CMD_ACK  		0x00
#define SPP_CMD_RST  		0x01
#define SPP_CMD_ADV_EN 		0x02
#define SPP_CMD_ADV_INTL 	0x03
#define SPP_CMD_CON_INTL 	0x04
#define SPP_CMD_DISC  		0x05
#define SPP_CMD_TX_PWR 		0x06
#define SPP_CMD_DEV_NAME 	0x07
#define SPP_CMD_TO_SPP 		0x08
#define SPP_CMD_VER 		0x09
#define SPP_CMD_UPD_STA		0x0a
#define SPP_CMD_MESH_NETID	0x0b
#define SPP_CMD_MESH_EN		0x0c
#define SPP_CMD_UPDATE		0xdd
#define SPP_CMD_TEST		0xee

#define SPP_CMD_START		0x55
#define SPP_CMD_END			0xaa

