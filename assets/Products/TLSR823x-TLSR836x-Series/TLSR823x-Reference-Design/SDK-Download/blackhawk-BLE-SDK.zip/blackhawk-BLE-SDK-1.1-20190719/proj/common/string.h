
#pragma once


// do not return void*,  otherwise, we must use a variable to store the dest porinter, that is not performance 
void   	memcpy4(void * dest, const void * src, size_t);

int ismemzero4(void *data, size_t len);
int ismemf4(void *data, size_t len);
void * memset4(void * dest, int val, size_t len);
void zeromem4(void *data, size_t len);
char tohex(unsigned char c);
int atoi(const char *s);
int isspace(int c);

#ifndef WIN32
void *  memset(void * d, int c, size_t n);
int		strcmp(const char *_s1, const char *_s2);
size_t	strlen(const char *_s);
char *	strcpy(char *_s1, const char *_s2);
void *  memcpy(void * des_ptr, const void * src_ptr, size_t n);
int		memcmp(const void *_s1, const void *_s2, size_t _n);
char *	strncat(char *_s1, const char *_s2, size_t _n);
char *	strncpy(char *_s1, const char *_s2, size_t _n);
int		strncmp(const char *_s1, const char *_s2, size_t _n);
char *	strcat(char *_s1, const char *_s2);
char *	strtok(char *_s1, const char *_s2);
char *	strerror(int _errcode);
int		strcoll(const char *_s1, const char *_s2);
void *  memmove(void * dest, const void * src, size_t n);
char * 	strchr (register const char *s, int c);
void * 	memchr (register const void * src_void, int c, size_t length);
void *	memchr(const void *_s, int _c, size_t _n);
char *	strchr(const char *_s, int _c);
char *	strpbrk(const char *_s1, const char *_s2);
char *	strrchr(const char *_s, int _c);
char *	strstr(const char *_s1, const char *_s2);
void stringToMac(u8 *s, int len, u8 *mac);
void macToString(u8 *s, u8 *mac);
char *strstr(const char *strLong, const char *strShort);
int mystrcpy(char * dst, const char * src);
int mystrcat ( char * dst , const char * src );
int myitoa(int num,char *buf,int radix);

#endif
