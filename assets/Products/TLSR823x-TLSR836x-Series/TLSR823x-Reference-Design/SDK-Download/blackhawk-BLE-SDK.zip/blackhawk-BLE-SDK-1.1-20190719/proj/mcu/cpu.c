
#include "../tl_common.h"

void cpu_reboot(void){
	reg_pwdn_ctrl = FLD_PWDN_CTRL_REBOOT;
	while(1);
}

