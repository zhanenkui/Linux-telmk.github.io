/********************************************************************************************************
 * @file     pm.c
 *
 * @brief    This is the source file for TLSR8231
 *
 * @author	 Telink
 * @date     May 12, 2019
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/


#include "bsp.h"

#include "compiler.h"
#include "register.h"
#include "gpio.h"
#include "analog.h"
#include "clock.h"
#include "irq.h"
#include "rf_drv.h"
#include "pm.h"
#include "timer.h"

unsigned int cpu_wakup_last_tick;

#define FLASH_DEEP_EN				0

/**
 * @brief     this function srevers to start sleep mode.
 * @param[in] none
 * @return    none
 */
_attribute_ram_code_ _attribute_no_inline_ void sleep_start(void)
{
#if FLASH_DEEP_EN  //8267 send flash wakeup cmd when reboot
	REG_ADDR8 (0x0d) = 0;
	REG_ADDR8 (0x0c) = 0xb9;
	for(volatile int i=0; i<2; i++); //1440ns when 32M clk
	REG_ADDR8 (0x0d) = 1;
#endif

	REG_ADDR8(0x5a1) &= 0x00;         //MSPI ie disable
	WRITE_REG8(0x80006f,0x81);
	for(volatile int i = 0; i<6; i++);//4.25us(24MHz)
	REG_ADDR8(0x5a1) |= 0xff;         //MSPI ie enable

#if FLASH_DEEP_EN
	REG_ADDR8 (0x0d) = 0;
	REG_ADDR8 (0x0c) = 0xab;
	for(volatile int i=0; i<2; i++); //1440ns when 32M clk
	REG_ADDR8 (0x0d) = 1;
#endif
}

#define reg_wakeup_en			          REG_ADDR8(0x6e)

#define reg_32k_timer_counter_latch       REG_ADDR32(0x750)
#define reg_32k_timer_calibration_value   REG_ADDR16(0x748)

enum
{
	FLD_SYS_TIMER_EN                 	  = BIT(7),
	FLD_SYS_TIMER_IRQ_EN                  = BIT(6),
	FLD_SYS_TIMER_CAL_MODE                = BIT_RNG(4,5),
	FLD_SYS_TIMER_CAL_EN                  = BIT(3),
	FLD_SYS_TIMER_AUTO_MODE               = BIT(2),
	FLD_RSVD                              = BIT(1),
	FLD_SYS_TIMER_WRITE_32K_TICK_EN       = BIT(0),
};

#define reg_sys_timer_cmd_state           REG_ADDR8(0x74b)

enum {
    FLD_PM_SYSTIMER_32K_MANUAL_SYNC       = BIT(3),
    FLD_PM_SYSTIMER_32K_CLR_MANUAL	      = BIT(5),
};

#define reg_32k_timer_tick                REG_ADDR32(0x74c)

enum{
	 PM_AUTO_PWDN_32K   	= BIT(0),
	 PM_AUTO_PWDN_XTAL 	 	= BIT(2),
	 PM_AUTO_PWDN_ANA   	= BIT(3),
	 PM_AUTO_PWDN_EN    	= BIT(4),
	 PM_AUTO_PWDN_LLLDO 	= BIT(5),
	 PM_AUTO_PWDN_DLDO  	= BIT(6),
	 PM_AUTO_PWDN_ISO   	= BIT(7),

	 PM_AUTO_PWDN_SUSPEND   = 0X5e,
	 PM_AUTO_PWDN_DEEPSLEEP = 0Xfe,
};

/**
 * @brief   This function serves to get the 32k tick.
 * @param   none
 * @return  variable of 32k tick.
 */
_attribute_ram_code_ static unsigned int pm_get_32k_tick (void)
{
	reg_sys_timer_ctrl = 0x20;
	reg_sys_timer_cmd_state |= FLD_PM_SYSTIMER_32K_CLR_MANUAL;
	while(!(reg_sys_timer_cmd_state & FLD_PM_SYSTIMER_32K_CLR_MANUAL));

	return reg_32k_timer_counter_latch;
}

/**
 * @brief   This function serves to set the 32k tick.
 * @param   tick - variable of 32k tick.
 * @return  none.
 */
_attribute_ram_code_ static void pm_set_32k_tick (unsigned int tick)
{
	reg_sys_timer_ctrl = 0x21;
	while(reg_sys_timer_cmd_state&0x40);
	reg_32k_timer_tick  = tick;
	reg_sys_timer_cmd_state |= FLD_PM_SYSTIMER_32K_MANUAL_SYNC;
	while(!(reg_sys_timer_cmd_state & FLD_PM_SYSTIMER_32K_MANUAL_SYNC));
	while(reg_sys_timer_cmd_state & FLD_PM_SYSTIMER_32K_MANUAL_SYNC);
}

/**
 * @brief     This function serves to wake up cpu from stall mode by timer0.
 * @param[in] tick - capture value of timer0.
 * @return    none.
 */
void mcu_stall_wakeup_by_timer0(unsigned int tick)
{
    reg_tmr0_tick = 0;

    reg_tmr0_capt = tick;
    reg_tmr_ctrl8 |= FLD_TMR0_EN;          //enable TIMER1,mode:using sclk
    reg_mcu_wakeup_mask |= FLD_IRQ_TMR0_EN;//timer1 mask enable
    reg_tmr_sta = FLD_TMR_STA_TMR0;        // clean interrupt

    WRITE_REG8(0x6f,0x80);                 //stall mcu
    asm("tnop");
    asm("tnop");

    reg_tmr_sta = FLD_TMR_STA_TMR0;        // clean interrupt
    reg_tmr_ctrl8 &= ~FLD_TMR0_EN;         //disable TIMER1
}

/**
 * @brief   This function serves to wake up cpu from stall mode by timer1.
 * @param   tick - capture value of timer1.
 * @return  none.
 */
void mcu_stall_wakeup_by_timer1(unsigned int tick)
{
    reg_tmr1_tick = 0;

    reg_tmr_ctrl8 |= FLD_TMR1_EN;          //enable TIMER1,mode:using sclk
    reg_mcu_wakeup_mask |= FLD_IRQ_TMR1_EN;//timer1 mask enable
    reg_tmr_sta = FLD_TMR_STA_TMR1;        //clean interrupt

    WRITE_REG8(0x6f,0x80);				   //stall mcu
    asm("tnop");
    asm("tnop");

    reg_tmr_sta = FLD_TMR_STA_TMR1;        // clean interrupt
    reg_tmr_ctrl8 &= ~FLD_TMR1_EN;         //disable TIMER1
}

/**
 * @brief     This function serves to wake up cpu from stall mode by timer2.
 * @param[in] tick - capture value of timer2.
 * @return    none.
 */
void mcu_stall_wakeup_by_timer2(unsigned int tick)
{
    reg_tmr2_tick = 0;

    reg_tmr2_capt = tick;
    reg_tmr_ctrl8 |= FLD_TMR2_EN;          //enable TIMER1,mode:using sclk
    reg_mcu_wakeup_mask |= FLD_IRQ_TMR2_EN;//timer1 mask enable
    reg_tmr_sta = FLD_TMR_STA_TMR2;        //clean interrupt

    WRITE_REG8(0x6f,0x80);                 //stall mcu
    asm("tnop");
    asm("tnop");

    reg_tmr_sta = FLD_TMR_STA_TMR2;        //clean interrupt
    reg_tmr_ctrl8 &= ~FLD_TMR2_EN;         //disable TIMER1
}

/**
 * @brief      This function configures a GPIO pin as the wake up pin.(NOT ALL THE GPIOs)
 * @param[in]  pin - the pin needs to be configured as wake up pin.Just include PA<7:5>,PB<7:0>.
 * @param[in]  pol - the wake up polarity of the pad pin(0: low-level wake up, 1: high-level wake up)
 * @param[in]  en  - enable or disable the wake up function for the pan pin(1: Enable, 0: Disable)
 * @return     none
 */
#define AREG_PAD_WAKEUP_EN(i)		((i>>8) + 0x27)
#define AREG_PAD_WAKEUP_POL(i)		((i>>8) + 0x21)
void pm_set_gpio_wakeup(GPIO_PinTypeDef pin, GPIO_LevelTypeDef pol, int en )
{
	// 		   PA[7:5]		    	   PB[7:0]
	// pol:  ana_21<7:0>			 ana_22<7:0>
	// en:	 ana_27<7:0>	 		 ana_28<7:0>

    unsigned char mask = pin & 0xff;
	unsigned char areg;
	unsigned char val;

	////////////////////////// polarity ////////////////////////
	areg = AREG_PAD_WAKEUP_POL(pin);
	val = analog_read(areg);
	if (pol) {
		val &= ~mask;
	}
	else {
		val |= mask;
	}
	analog_write (areg, val);

	/////////////////////////// enable /////////////////////
	areg = AREG_PAD_WAKEUP_EN(pin);
	val = analog_read(areg);
	if (en) {
		val |= mask;
	}
	else {
		val &= ~mask;
	}
	analog_write (areg, val);
}

/**
 * @brief      This function serves to set the working mode of MCU,e.g. suspend mode, deep sleep mode,
 * 			   deep sleep with SRAM retention mode and shutdown mode.If CAN'T RECEIVE package,delay almost 200us.
 * @param[in]  deepsleep - sleep mode type select.
 * @param[in]  wakeup_src - wake up source select.
 * @param[in]  wakeup_tick - the time of short sleep, which means MCU can sleep for less than 5 minutes.
 * @param[in]  inter_cap - the value to set internal cap.1 -- open internal cap. 0 -- close internal cap.
 * @return     indicate whether the cpu is wake up successful.
 */
extern unsigned char internal_cap_flag;
_attribute_ram_code_ int pm_sleep_wakeup(SleepMode_TypeDef deepsleep, SleepWakeupSrc_TypeDef wakeup_src,unsigned int wakeup_tick)
{

	int timer_wakeup_enable = (wakeup_src & PM_WAKEUP_TIMER);
	unsigned short tick_32k_calib = REG_ADDR16(0x748);
	unsigned short  tick_32k_halfCalib = tick_32k_calib>>1;
	unsigned char long_suspend = 0;
	unsigned int span = (unsigned int)(wakeup_tick - get_sys_tick());

	if(timer_wakeup_enable)
	{
		if (span > 0xE0000000)  //BIT(31)+BIT(30)+BIT(19)   7/8 cylce of 32bit
		{
			return  analog_read (0x44) & 0x0f;
		}
		else if (span < EMPTYRUN_TIME_US * tl_sys_tick_per_us) // 0 us base
		{
			unsigned int t = get_sys_tick();
			analog_write (0x44, 0x0f);			//clear all status

			unsigned char st;
			do
			{
				st = analog_read (0x44) & 0x0f;
			} while ( ((unsigned int)get_sys_tick() - t < span) && !st);
			return st;

		}
		else
		{
			if( span > 0x0ff00000 )	//BIT(28) = 0x10000000   16M:16S
			{
				long_suspend = 1;
			}
		}
	}

	////////// disable IRQ //////////////////////////////////////////
	unsigned char r = irq_disable ();

	reg_sys_timer_ctrl = 0xa0;//0xa8;//Enable 32k tick read,close calibrate.
	reg_sys_timer_cmd_state = BIT(5);//Clear 32k read latch update flag.

	asm("tnop");asm("tnop");asm("tnop");asm("tnop");
	asm("tnop");asm("tnop");asm("tnop");asm("tnop");
	asm("tnop");asm("tnop");asm("tnop");asm("tnop");
	asm("tnop");asm("tnop");asm("tnop");asm("tnop");

	while(!(reg_sys_timer_cmd_state & BIT(5)));//Wait 32k latch register update.

	unsigned int tick_32k_cur = reg_32k_timer_counter_latch;

	unsigned int tick_cur = get_sys_tick();

	reg_sys_timer_ctrl = 0x20;

	unsigned int tick_wakeup_reset = wakeup_tick - EARLYWAKEUP_TIME_US * tl_sys_tick_per_us;
	/* Set digital/analog wake-up source. */
	analog_write(0x26, wakeup_src|(PM_PAD_FILTER_EN ? BIT(3) : 0x00));

	//if digital wake-up is enabled,Select digital wake-up.
	WRITE_REG8(0x6e, (wakeup_src & PM_WAKEUP_CORE) ? 0x08 : 0x00);

	analog_write (0x44, 0x0f);//Clear wake-up flag.


    /* Power down the corresponding module. */
	unsigned char rc32k_power_down = 0;
	if (wakeup_src & PM_WAKEUP_TIMER )
	{
		rc32k_power_down = 0x00;//32K RC need be enabled
	}
	else
	{
		rc32k_power_down = 0x00 | (PM_PAD_FILTER_EN ? 0:1);//32K RC power
	}

	// Switch system clock to 24M RC.
	unsigned char reg66 = READ_REG8(0x66);
	WRITE_REG8 (0x66, 0x00);

	//32K RC power-down.
	analog_write(0x2c, (deepsleep ? 0xfe : 0x7e) | rc32k_power_down);

	/* Set power-on delay time when MCU is waked up. */
	span = (RESET_TIME_US * tl_sys_tick_per_us * 16 + tick_32k_halfCalib) / tick_32k_calib;

	/* Set 32k wake-up tick. */
	unsigned int tick_32k_wakeup;

	if(long_suspend)
	{
		tick_32k_wakeup = tick_32k_cur + (unsigned int)(tick_wakeup_reset - tick_cur)/ tick_32k_calib * 16;
	}
	else{
		tick_32k_wakeup = tick_32k_cur + ((unsigned int)(tick_wakeup_reset - tick_cur) * 16 + tick_32k_halfCalib) / tick_32k_calib;
	}

	unsigned char rst_cycle = 0xff - span;
	analog_write (0x20, rst_cycle);
	pm_set_32k_tick(tick_32k_wakeup);

	analog_write(0x44, 0x0f);//Clear wake-up flag.

	if(deepsleep  & 0xf0){//Retention mode en
		if(RetentionModeFlag == RETENTION_REF_VOL_1_2V){
			analog_write(0x03, analog_read(0x01)|0x08);
		}
		else if(RetentionModeFlag == RETENTION_REF_VOL_1_8V){
			analog_write(0x03, analog_read(0x01)&0xf7);
		}
		analog_write(0x7f, 0x02);//retention select,boot from ram
	}

	//Native LDO power down.(Must)
	if(deepsleep)
	{
		analog_write(0x01, analog_read(0x01)|0x80);
		analog_write(0x04, analog_read(0x04)|0x01);
	}
	else
	{
		//digital LDO pull down disable
		analog_write(0x01, analog_read(0x01)&0x7f);
		analog_write(0x04,analog_read(0x04)&0xfe);
		analog_write(0x01, analog_read(0x01)|0x08);
	}
	#if CHIP_5317_A1
	 analog_write(0x01, analog_read(0x01)|0x80);
	#endif
	analog_write(0x44, 0x0f);//Clear wake-up flag.

	unsigned char analog80 = analog_read(0x80);
    unsigned char analog81 = analog_read(0x81);
	if(internal_cap_flag){
	     analog_write(0x80,0x21);//disable on-chip cap
	     analog_write(0x81,0xc0);//on-chip binary array lowest .
	}

//	analog_write(0x81,0xcf);//Increase XTAL current.(user for PM driver test.)
	/* Enter low power mode. */
	if(analog_read(0x44)&0x0f){

	}
	else
	{
		sleep_start();
	}
	if(deepsleep){
			WRITE_REG8(0x6f, 0x20);  //reboot
		}

	/* suspend recover setting. */
	analog_write (0x2c, 0x00);
#if CHIP_5317_A1
	analog_write(0x01, analog_read(0x01)&0x7f);
#endif
//	analog_write(0x01, 0x77);//4.2us
	analog_write(0x01, analog_read(0x01)&0xf7);
	analog_write(0x04,analog_read(0x04)|BIT(0));
	analog_write(0x01, analog_read(0x01)|BIT(7));
	unsigned int tick_32k = pm_get_32k_tick();//3us - 40us

	if(long_suspend){
		tick_cur += (unsigned int)(tick_32k - tick_32k_cur) / 16 * tick_32k_calib;
	}
	else{
		tick_cur += (unsigned int)(tick_32k - tick_32k_cur) * tick_32k_calib / 16 ;		// current clock
	}

	REG_ADDR8(0x66) = reg66;//restore system clock

	if((unsigned int)((wakeup_tick - 16) - tick_cur ) > BIT(30))
	{
		tick_cur = wakeup_tick - 32;
	}
	reg_system_tick = tick_cur;
	cpu_wakup_last_tick = get_sys_tick();
	REG_ADDR8(0x74a) = 0x00;//clear
	REG_ADDR8(0x74a) = 0xa8;//recover system timer and enable calibrate

	unsigned char anareg44 = analog_read(0x44) & 0x0f;

	if(!anareg44){ //GPIO if wrong can't get in suspend
		anareg44 = STATUS_GPIO_ERR_NO_ENTER_PM;
	}
	else if ( (anareg44 & WAKEUP_STATUS_TIMER) && (wakeup_src & PM_WAKEUP_TIMER) )	//wakeup from timer only
	{
		while ((unsigned int)(get_sys_tick() -  wakeup_tick) > BIT(30));
	}

	/* Exit critical region. */
	irq_restore(r);
	if(internal_cap_flag){
	     analog_write(0x80,analog80);//disable on-chip cap
	     analog_write(0x81,analog81);//on-chip binary array lowest .
	}
	return anareg44;
}

/**
 * @brief     This function servers to set a pin as wakeup source.
 * @param[in] pin - the pin needs to be wakeup.
 * @param[in] level - the type of level to wakeup a pin.
 * @param[in] en - enable or disable the pin's function of interrupt(1: enable, 0: disable).
 * @return    none
 */
unsigned char gpio_set_wakeup(GPIO_PinTypeDef pin, GPIO_LevelTypeDef level, int en)
{
	unsigned char bit = pin & 0xff;
	unsigned char flag=0;
    if (en)
    {
        BM_SET(reg_gpio_irq_wakeup_en(pin), bit);
    }
    else
    {
        BM_CLR(reg_gpio_irq_wakeup_en(pin), bit);
    }

    if(level)
    {
        BM_CLR(reg_gpio_pol(pin), bit);
        flag=1;
    }
    else
    {
        BM_SET(reg_gpio_pol(pin), bit);
    }

    gpio_set_func(pin,AS_GPIO);
    gpio_set_input_en(pin,1);//must
    reg_gpio_wakeup_and_irq_en |= FLD_GPIO_CORE_WAKEUP_EN;

    return flag;
}

/**
 * @brief:    Set pad filter.
 * @param[in] en - enable or disable the pin's function of interrupt(1: enable, 0: disable).
 * @return:   none.
 */
void pm_set_filter(unsigned char en)
{
	unsigned char tmp;
	tmp = analog_read(0x26);
	if(en)
	{
		tmp |= BIT(3);
	}
	else
	{
		tmp &= ~BIT(3);
	}
	analog_write (0x26, tmp);
}







