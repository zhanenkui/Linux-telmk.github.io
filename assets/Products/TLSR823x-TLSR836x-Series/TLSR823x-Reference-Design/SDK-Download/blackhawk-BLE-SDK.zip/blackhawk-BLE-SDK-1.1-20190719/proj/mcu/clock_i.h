
#pragma once

#ifdef WIN32
static inline unsigned __int64   clock_get_cycle()
{ 
  __asm   _emit   0x0F 
  __asm   _emit   0x31 
}
#endif

static inline u32 clock_time(void){
	return reg_system_tick;
}

// check if the current time is exceed span_us from ref time
static inline u32 clock_time_exceed_tick(u32 ref, u32 span){
	return ((u32)(clock_time() - ref) > span);
}

// check if the current time is exceed span_us from ref time
static inline u32 clock_time_exceed(u32 ref, u32 span_us){
	return ((u32)(clock_time() - ref) > span_us * CLOCK_SYS_CLOCK_1US);
}

