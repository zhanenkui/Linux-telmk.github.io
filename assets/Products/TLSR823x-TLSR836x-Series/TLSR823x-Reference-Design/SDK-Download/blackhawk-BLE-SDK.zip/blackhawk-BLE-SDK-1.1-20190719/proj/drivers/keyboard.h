
#pragma once

#include "../drivers/usbkeycode.h"

#define IRK_POWER				(0x40)
#define IRK_MENU				(0x4c)
#define IRK_UP					(0x16)
#define IRK_DOWN 				(0x1a)
#define IRK_LEFT 				(0x51)
#define IRK_RIGHT				(0x50)
#define IRK_ENTER				(0x13)
#define IRK_HOME				(0x11)
#define IRK_MUTE				(0x41)
#define IRK_BACK				(0x19)
#define IRK_VOL_DN				(0x10)
#define IRK_VOL_UP				(0x18)
#define IRK_MOUSE				(0x00)


#define KB_RETURN_KEY_MAX		2

// ========================================================
typedef struct{
	u8 ctrl;
	u8 cnt;
	u8 keycode[KB_RETURN_KEY_MAX];
	//u8 padding[2];	//  for  32 bit padding,  if KB_RETURN_KEY_MAX change,  this should be changed
}kb_data_t;

u8 kb_key_checked(void);
u32 kb_scan_key(kb_data_t *data);

