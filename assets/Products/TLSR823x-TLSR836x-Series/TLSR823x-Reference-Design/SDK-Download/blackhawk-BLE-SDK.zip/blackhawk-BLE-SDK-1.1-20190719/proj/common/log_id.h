
#pragma once

/*
	ID == -1 is invalid
	if you want to shut down logging a specified id,  assigne -1 to it
*/


///////////////////////////////////////////////////////////////

// Please donot change the following system defines
// 

#define TR_T_invalid			-1
#define TR_T_SYS_TIMER_IRQ		0
#define TR_T_TX_IRQ				1
#define TR_T_LL_RECV_DATA		2
#define TR_T_PHY_RX_TIMEOUT_IRQ	3
#define TR_T_PHY_CMD_DONE_IRQ	4
#define TR_T_NEXT_CHANNEL		5
#define TR_T_ENTER_SUSPEND		6
#define TR_T_EXIT_SUSPEND		7

#define TR_24_TIMERS_ADDR		0	// this ID cant be used because timer id == 0 is reserved for indicating id not added


