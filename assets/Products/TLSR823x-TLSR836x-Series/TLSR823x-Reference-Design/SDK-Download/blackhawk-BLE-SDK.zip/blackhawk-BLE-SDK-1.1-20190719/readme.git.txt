Things that you should learn first

-- Pro Git book
   http://git-scm.com/book
   this is the fundamental and introduction of the git

-- Git online references
   http://git-scm.com/docs
   all the commands are here

-- Install TortoiseGIT and/or GitHub GitExtensions
