#pragma once

#include "../../proj/tl_common.h"
#include "hci.h"


/*********************************************************************
 * CONSTANTS
 */
#define HCI_MAX_ACL_DATA_LEN              27
#define HCI_MAX_DATA_BUFFERS              4

/**
 *  @brief  Definition for HCI ACL Data PB Flag
 */
#define HCI_FIRST_NAF_PACKET              0x00
#define HCI_CONTINUING_PACKET             0x01
#define HCI_FIRST_AF_PACKET               0x02

