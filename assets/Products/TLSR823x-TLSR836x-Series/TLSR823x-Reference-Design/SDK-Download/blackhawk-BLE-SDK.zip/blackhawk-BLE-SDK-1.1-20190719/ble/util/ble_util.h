#pragma once


/*********************************************************************
 * CONSTANTS
 */

    
/*********************************************************************
 * ENUMS
 */


/**
 *  @brief  Module Definition for power management
 */
typedef enum {
    PM_INFO_STACK_MODULE,
    PM_INFO_USER_MODULE,
} pmInfo_module_t;


/**
 *  @brief  ID Definition for STACK MODULE
 */
typedef enum {
    PM_INFO_ID_LL_STATE,
    PM_INFO_ID_GAP_STATE,
    PM_INFO_ID_PROFILE_STATE,
    PM_INFO_ID_BB_SUPERVISON_CNT,
    PM_INFO_ID_BB_SN,
    PM_INFO_ID_BB_NESN,
    PM_INFO_ID_LL_TX_CNT,
    PM_INFO_ID_LL_RX_CNT,
} pmInfo_stackId_t;

/*********************************************************************
 * TYPES
 */

/**
 *  @brief  Definition for PM information structure
 */
typedef struct {

    /* Analog Reg: 0x30, 0x31 */
    union {
        struct {
            u8 ll_state      :4;
            u8 gap_state     :4;
            u8 profile_state :4;
            u8 reserved      :4;
        }bf;
        u16 value;
    } states; 

    /* Analog Reg: 0x32, 0x33 */
    union {
        struct {
            u16 supervisionCnt:14;
            u16 sn            :1;
            u16 nesn          :1;
        } bf;
        u16 value;
    } bbCtrl; 

    /* Analog Reg: 0x34~0x37 */
    u32 ll_txPktCnt;

    /* Analog Reg: 0x38~0x3b */
    u32 ll_rxPktCnt;

    /* Analog Reg: 0x3c~0x3f, reserved for user app use */
    
} ble_pmInfo_t;




/*********************************************************************
 * GLOBAL VARIABLES
 */

// for internal use


/*********************************************************************
 * Public Functions
 */

/*********************************************************************
 * @fn      ble_pmInfo_load
 *
 * @brief   Load the stack information stored in analog register. This 
 *          function usually be called after wake up from deep sleep.
 *
 * @param   None
 *
 * @return  None
 */
void ble_pmInfo_load(pmInfo_stackId_t id, u8* retVal);

/*********************************************************************
 * @fn      ble_pmInfo_save
 *
 * @brief   Save the stack information to analog register, this funcion
 *          usually be called before enter deep sleep.
 *
 * @param   None
 *
 * @return  None
 */
void ble_pmInfo_save(void);


