#pragma once

#include "../ble_common.h"
#include "gap_config.h"
#include "gap_const.h"
#include "gap.h"
#include "gap_peripheral.h"
#include "../attr/gatt_server.h"
#include "gap_attServer.h"
#include "gap_utils.h"
#include "../smp/smp_include.h"
#include "gap_link.h" 