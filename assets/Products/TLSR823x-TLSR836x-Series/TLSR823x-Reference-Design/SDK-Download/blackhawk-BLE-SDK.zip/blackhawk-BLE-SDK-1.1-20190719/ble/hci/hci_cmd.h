#pragma once

#include "../../proj/tl_common.h"
#include "hci.h"
#include "../controller/ll/ll_advertising.h"
