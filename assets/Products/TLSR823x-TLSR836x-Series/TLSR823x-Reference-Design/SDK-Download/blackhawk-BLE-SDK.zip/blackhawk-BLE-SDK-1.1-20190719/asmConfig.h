
#pragma once

///////////////////////////////////////////////////////////////
#define CHIP_8366				1	//  !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_8263				2	//  !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_8266				3	//  !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_5313				4	//  5316 !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_5316				5	//  5316 !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_5317				6	//  5317 !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_8267				7	//  !!  Keep this definition ORDER, we use comparation elsewhere
#define CHIP_8258				8	//  !!  Keep this definition ORDER, we use comparation elsewhere
#define IS_8366					(CHIP_TYPE == CHIP_8366)
#define IS_8263					(CHIP_TYPE == CHIP_8263)
#define IS_8266					(CHIP_TYPE == CHIP_8266)
#define IS_8267					(CHIP_TYPE == CHIP_8267)
#define IS_5313					(CHIP_TYPE == CHIP_5313)
#define IS_5316					(CHIP_TYPE == CHIP_5316)
#define IS_5317					(CHIP_TYPE == CHIP_5317)
#define IS_8369					(IS_5316 || IS_5317 || IS_5313)
#define IS_8258					(CHIP_TYPE == CHIP_8258)
#define IS_SW_BLE				(CHIP_TYPE <= CHIP_8263)
#define IS_HW_BLE				(!IS_SW_BLE)
#define IS_SW_OTA				(CHIP_TYPE <= CHIP_8266)
#define CHIP_HAS_OTP			(IS_8263 || IS_8366 || IS_5313)
///////////////////////////////////////////////////////////////
#define PROJECT_TYPE_HID			1
#define PROJECT_TYPE_MESH			2					// LaoBan DianQi
#define PROJECT_TYPE_SPP			3					// BL05
#define PROJECT_TYPE_SPP_UART_OTA	4					// HongQuan
#define PROJECT_TYPE_AUDIO			5
#define PROJECT_TYPE_SNIFFER		6
#define PROJECT_TYPE_SDKLIZE		10

#define IS_SNIFFER				(PROJECT_TYPE == PROJECT_TYPE_SNIFFER)
#define IS_SDK					(PROJECT_TYPE == PROJECT_TYPE_SDKLIZE)
///////////////////////////////////////////////////////////////
#define CHIP_TYPE				CHIP_5313	//  modify boot.link too:   RAM_START_ADDR,  RUN_ALL_IN_RAM
#define PROJECT_TYPE			PROJECT_TYPE_SDKLIZE

#define RUN_ALL_IN_RAM			0 	// (!(IS_8263 || IS_8366 || IS_5313))		// app_config.h,  cstartup.s,  boot_link ( 2 places: FILL-size, bss-addr)
#define RUN_ON_FLASH			0	//  because  of OTA  enable

#define BLE_SLAVE_ENABLE		1
#define BLE_MASTER_ENABLE		0
#define DONGLE_TEST_MODE_ENABLE	0
#define SLAVE_WITH_PRIV_MASTER 	(DONGLE_TEST_MODE_ENABLE && is_dongleTestMode)	// slave  with private protocol master, that is use simplest protocol.  Always false when work with cell phone

#define CONN_USE_IRQ			(IS_HW_BLE)
#define OTA_FLASH_ADDR_START	0x20000			// 8267 must >= 128K,  8261 must >= 64K
#define FLASH_MAX_PROGRAM_SIZE	0x4000			// 16K
#define FLASH_SECTOR_SIZE		0x1000			// !!!! Ҫ��ʵ�ʵ�spec д

#define SMALL_SPACE_LVL1		0
#define SMALL_SPACE_LVL2		0

#define UART_SIMU				(!IS_HW_BLE)
#define UART_HALFDUP_ARBI		0
#define UART_CRC_ENABLE 		0
#define SPP_OTA_ENABLE			0
#define SPP_LOCAL_CMD_ENABLE	0

#if(0 && RUN_ALL_IN_RAM && CHIP_HAS_OTP)
#define HID_ENABLE				0
#define	SMP_ENABLE				0
#define BROADCAST_MESH_ENABLE	0

#define SPP_ENABLE				0
#define UART_ENABLE				0
#define OTA_ENABLE				0

#define IRQ_ENABLE				CONN_USE_IRQ		//  because  of uart  enable
#define GPIO_IRQ_ENABLE			0		//  because  of uart  enable
#define WEIXIN_SUPPORT			0
#define CONNECT_UP_ENABLE		0

#define SMALL_SPACE_LVL1		1
#define SMALL_SPACE_LVL2		1

#else

#define HID_ENABLE				1
#define	SMP_ENABLE				1
#define BROADCAST_MESH_ENABLE	0

#define SPP_ENABLE				1
#define OTA_ENABLE				0
#define UART_ENABLE				1
#define IRQ_ENABLE				(CONN_USE_IRQ || UART_ENABLE)

#define GPIO_IRQ_ENABLE			1
#define WEIXIN_SUPPORT			0
#define CONNECT_UP_ENABLE		1

#endif

#define	PKT_BUFF_SIZE 			64	// ��Ϊ cstartup.s has more than 112 bytes, no need to reduce PKT_BUFF_SIZE, though 52 may also work
#if(SMP_ENABLE || BLE_MASTER_ENABLE)	// pkt_connect == 51 for master
#define	PKT_TX_BUFF_SIZE 		(40 + 12) // dma + T + L + payload + crc(3) + MIC(4) + 4 * crcs(3) == 4 + 2 + 27 + 3 + 12 == 52
#else
#define	PKT_TX_BUFF_SIZE 		(36 + 12) // dma + T + L + payload + crc(3) + 4 * crcs(3) == 4 + 2 + 27 + 3 + 12 == 48
#endif

#if(IS_8263 || IS_8366 || IS_5313)
	#define RAM_START_ADDR		0x808000	// 32K
	#if(IS_5313)
	#define RAM_SIZE			0x2000		// 8k
	#else
	#define RAM_SIZE			0x1800 		// 6K
	#endif
	#if(CONN_USE_IRQ || UART_ENABLE)
	#define IRQ_STK_SIZE		0xe0	// ����ʵ����Ҫ�޸ģ� ��� ram ������ 0x200 ��һ����ѡ��, ���� 8263 �����жϣ������� 0x40
	#else
	#define IRQ_STK_SIZE		0x40
	#endif

	#if(CONN_USE_IRQ)
	#define PKT_RX_BUFF_CNT		(4)
	#else
	#define PKT_RX_BUFF_CNT		(1)
	#endif
	#define SW_BOOT_CHECK		(OTA_ENABLE && IS_SW_OTA)
	#define RSV_RAM_FOR_APP 	0
#elif(CHIP_TYPE < CHIP_8258)	
	#define RAM_START_ADDR		0x808000	// 32K
	#define RAM_SIZE			0x4000		// 16K
	#define IRQ_STK_SIZE		0x200

	#if(CONN_USE_IRQ)
	#define PKT_RX_BUFF_CNT 	(IS_SNIFFER?8:4)
	#else
	#define PKT_RX_BUFF_CNT 	(IS_SNIFFER?8:1)
	#endif
	#define SW_BOOT_CHECK		(OTA_ENABLE && IS_SW_OTA)
	#define RSV_RAM_FOR_APP 	0			// (IRQ_ENABLE*0x38 + PKT_BUFF_SIZE * PKT_RX_BUFF_CNT) // no need SW TX buffer
#else
	// 8258
	#define RAM_START_ADDR		0x840000	// 32K
	#define RAM_SIZE			0x10000		// 64K
	#define IRQ_STK_SIZE		0x200

	#if(CONN_USE_IRQ)
	#define PKT_RX_BUFF_CNT 	(8)
	#else
	#define PKT_RX_BUFF_CNT 	(IS_SNIFFER?8:1)
	#endif
	#define SW_BOOT_CHECK		(OTA_ENABLE && IS_SW_OTA)
	#define RSV_RAM_FOR_APP 	0 			// (IRQ_ENABLE*0x38 + PKT_BUFF_SIZE * PKT_RX_BUFF_CNT) // no need SW TX buffer

	#define PM_DEEP_RET_RAM		PM_SLEEPMODE_RET_NONE
#endif
#define STACK_END_ADDR			(RAM_START_ADDR + RAM_SIZE)

#if(RUN_ON_FLASH)	
#define HIGH_SPI_SPEED			(IS_5313)	// 5313 must, or sometimes connect fail   (!IS_8258)	 be aware that some flash do not support dual read mode	//  for  8258,  always 0
#define HIGH_OTP_SPEED			0
#else
#define HIGH_SPI_SPEED			(IS_5313)
#define HIGH_OTP_SPEED			1			//(!IS_8258)		//  for  8258,  always 0
#endif

