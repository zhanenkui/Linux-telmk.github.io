MK_DIRECTORY=diff_$(date +%y%m%d_%H_%M_%S)
mkdir $MK_DIRECTORY



for i in `git status`
	do 
		if [ "$i" = "project" ];then			
			TYPE="project"
		elif [ "$i" = "-m" ] || [ $i = "--" ];then
			TYPE="flies"
		elif [ "$i" = "-d" ];then
			TYPE="del"
		elif [ "$TYPE" = "no" ];then
			echo
		else
			if [ "$TYPE" = "project" ];then
				PROJECT=$i
				TYPE="no"
			elif [ "$TYPE" = "flies" ];then			
				#echo -e "\033[32m  [[[${PROJECT}$i]]] \033[0m"
				cp ${PROJECT}$i $MK_DIRECTORY --parents	
				if [ $? = 1 ];then
						#文件名有空格 cp会失败，尝试用`ls a*`得到的文件名cp
						FILE_NAME=`ls ${PROJECT}$i*`
						echo -e "\033[31m  warning can't cp ${PROJECT}$i \033[0m"
						if [ "$FILE_NAME" != "" ];then
								cp "$FILE_NAME" $MK_DIRECTORY --parents	
								echo -e "\033[31m try cp "$FILE_NAME"\033[0m"	
						else
							 #echo -e "\033[31m can't find ${PROJECT}$i* \033[0m"	
							 echo 
						fi
						FILE_NAME=""
				else
						echo "modify/new ${PROJECT}$i"  >> $MK_DIRECTORY/modify.txt
				fi
							 
			elif [ "$TYPE" = "del" ];then
				echo "del ${PROJECT}$i"  >> $MK_DIRECTORY/modify.txt
			fi			
		fi		
	done
	
	echo done
