/********************************************************************************************************
 * @file     rtc.h 
 *
 * @brief    for TLSR chips
 *
 * @author	 telink
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/
#pragma once

#include "common/types.h"
#include "common/string.h"
#include "common/static_assert.h"
#include "common/utility.h"
#include "vendor/8258_ble_sample/app_config.h"
#include "clock.h"
#include "irq.h"


#define RTC_MODE  1

#if (RTC_MODE)

#define INTERVAL_5_MIN   1
#define INTERVAL_1_HOUR  2


#define STOREDATA_INTERVAL  INTERVAL_1_HOUR


#define UTC_TIME_1970    0
#define UTC_TIME_2019    1546272000
#define UTC_TIME_2200    7258089600

#define ONE_HOUR_SEC_NUM 3600
#define FIVE_MIN_SEC_NUM 300
#define SEC_12S_NUM      12


u8   set_utc_time(u32 set_utc_time);
u32  get_utc_time(void);
void rtc_run(void);

u32 get_utc_from_1970_next_hour(void);
void set_utc_from_1970_next_hour(u32 utc_time_old_hour,u8 flag);

u32 get_utc_from_1970_next_five_min(void);
void set_utc_from_1970_next_five_min(u32 utc_time_old_five_min,u8 flag);


#endif



