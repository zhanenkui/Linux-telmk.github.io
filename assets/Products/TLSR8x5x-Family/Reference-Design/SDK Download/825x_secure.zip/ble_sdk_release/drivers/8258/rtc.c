/********************************************************************************************************
 * @file     rtc.c 
 *
 * @brief    for TLSR chips
 *
 * @author     telink
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *             The information contained herein is confidential and proprietary property of Telink 
 *              Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *             of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *             Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 *              Licensees are granted free, non-transferable use of the information in this 
 *             file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/
/**************************************************************************************************
  Filename:           rtc.c
  Author:            
  Created Date:    
  
  Description:    

**************************************************************************************************/

#include "rtc.h"
#include "timer.h"
#include "drivers/8258/compiler.h"
#include "stack/ble/service/ble_ll_ota.h"


#if (RTC_MODE)



_attribute_data_retention_ u32 utc_from_1970 = UTC_TIME_1970;


u8 set_utc_time(u32 set_utc_time){
   utc_from_1970 = set_utc_time;

    return 1;
}

u32 get_utc_time(void){
     return utc_from_1970;
}

u32 get_utc_from_1970_next_hour(void){
    return ((utc_from_1970 - utc_from_1970%ONE_HOUR_SEC_NUM)+ONE_HOUR_SEC_NUM);
}

u32 get_utc_from_1970_next_five_min(void){
    return ((utc_from_1970 - utc_from_1970%FIVE_MIN_SEC_NUM)+FIVE_MIN_SEC_NUM);
}


//extern void loop_datanode_proc();
//extern void loop_utc_store_proc();

void rtc_utc_proc(int cnt_s)
{
    for(int i=0;i<cnt_s;i++){
        utc_from_1970++;

        if(utc_from_1970%ONE_HOUR_SEC_NUM == 0){
            //loop_datanode_proc();
        }
        if(utc_from_1970%FIVE_MIN_SEC_NUM == 0){
            if(blcOta.ota_start_flag == 0){
                //loop_utc_store_proc();
            }
        }    
    }
}
_attribute_ram_code_ void rtc_run(void){
    static u32 tick_rtc_run;
    if(clock_time_exceed(tick_rtc_run, 1000*1000)){  // less irq_disable() should be better.
        tick_rtc_run += CLOCK_SYS_CLOCK_1S;
        rtc_utc_proc(1);
    }
}

#endif


