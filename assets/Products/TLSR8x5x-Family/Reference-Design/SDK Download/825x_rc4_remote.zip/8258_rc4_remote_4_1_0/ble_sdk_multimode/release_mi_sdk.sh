dir_release=../mi_ble_certify_8258
sdk_dir=$dir_release
rm -rf $dir_release
mkdir $dir_release
cp -rf application boot common drivers proj_lib stack vendor  $sdk_dir
cp * .project .cproject $sdk_dir
find $sdk_dir/vendor/common/mijia_ble_api_master/ble_encrypt -name *.c |xargs rm -rf
find $sdk_dir -name *.zip |xargs rm -rf
find $sdk_dir -name *.rar |xargs rm -rf
rm -rf $sdk_dir/release_mesh.sh

cp mible_certi/libmible_certi.a	$sdk_dir/proj_lib


rm -rf $sdk_dir/*.IAB
rm -rf $sdk_dir/*.IAD
rm -rf $sdk_dir/*.IMB
rm -rf $sdk_dir/*.IMD
rm -rf $sdk_dir/*.PFI
rm -rf $sdk_dir/*.PO
rm -rf $sdk_dir/*.PR
rm -rf $sdk_dir/*.PRI
rm -rf $sdk_dir/*.PS
rm -rf $sdk_dir/*.SearchResults
rm -rf $sdk_dir/*.WK3
pause
::exit