
1. Add WatchDog initialization
/***************************************************************  
*@brief    for TLSR chips
* @date     Oct. 12, 2019
***************************************************************/

Add WatchDog initialized function according to Macro definition of "MODULE_WATCHDOG_ENABLE"and "WATCHDOG_INIT_TIMEOUT"
1. Replace file "../../telink_kite_ble_sdk_v3.4.0_20190816/ble_sdk_multimode/drivers/8258/clock.c" with "./clock.c"
2. Replace file "../../telink_kite_ble_sdk_v3.4.0_20190816/ble_sdk_multimode/drivers/8258/register_8258.h" with "./register_8258.h"