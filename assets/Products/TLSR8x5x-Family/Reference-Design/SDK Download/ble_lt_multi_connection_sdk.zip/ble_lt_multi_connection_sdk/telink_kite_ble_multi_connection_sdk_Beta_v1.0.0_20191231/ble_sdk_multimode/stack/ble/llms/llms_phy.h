/********************************************************************************************************
 * @file     llms_phy.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/
#ifndef LLMS_PHY_H_
#define LLMS_PHY_H_

#include "tl_common.h"
#include "drivers.h"
#include "llms_device.h"
#include "stack/ble/phy/phy.h"


#if(LL_FEATURE_ENABLE_LE_2M_PHY)


/******************************* User Interface  Begin *****************************************************************/

extern _attribute_aligned_(4) ll_conn_phy_t llms_blt_conn_phy[];

typedef int (*llms_conn_phy_update_callback_t)(u16 connHandle);
typedef int (*llms_conn_phy_switch_callback_t)(u16 connHandle);

extern 	llms_conn_phy_update_callback_t	llms_conn_phy_update_cb; ///blt_ll_updateConnPhy
extern 	llms_conn_phy_switch_callback_t	llms_conn_phy_swicth_cb; ///blt_ll_switchConnPhy

extern ll_conn_phy_t*	    blt_ll_get_conn_phy_ptr(u16 connHandle);

extern _attribute_ram_code_ int blt_ll_updateConnPhy(u16 connHandle);
extern _attribute_ram_code_ int blt_ll_switchConnPhy(u16 connHandle);

extern void blt_ll_sendPhyReq(u16 connHandle);
extern void blt_ll_sendPhyUpdateInd(u16 connHandle);

/******************************* User Interface  End  ******************************************************************/
#endif //end of LL_FEATURE_ENABLE_LE_2M_PHY


#endif /* LLMS_PHY_H_ */


