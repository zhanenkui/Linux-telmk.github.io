/********************************************************************************************************
 * @file     llms_scan.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_SCAN_H_
#define LLMS_SCAN_H_



/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/

#define	  		BLMS_SCAN_SLOT							  		64  //80*0.625 = 40mS
#define			BLMS_SCAN_INTERVL								( BLMS_SCAN_SLOT * CLOCK_16M_SYS_TIMER_CLK_625US)

#define			BLMS_PERCENT_MAX								128


_attribute_aligned_(4)
typedef struct {
	u8		scan_type;
	u8		scan_filterPolicy;
	u8		filter_dup;
	u8		scan_percent;  //to optimize code running effect, Denominator set to 128, "*128" -> "<<7",  "/128" -> ">>7"

	u8		scanDevice_num;
	u8		scanRspDevice_num;
	u8		scan_extension_mask;
	u8 		rsvd;

	u32		last_scan_end_time;
}st_llms_scan_t;

extern	_attribute_aligned_(4) st_llms_scan_t  blmsScn;



/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/








/******************************* Macro & Enumeration variables for User Begin ******************************************/



/******************************* Macro & Enumeration variables for User End ********************************************/





/******************************* Stack Interface Begin, user can not use!!! ********************************************/
void 	blt_llms_switchScanChannel (int set_chn);
int  	blt_llms_procScanPkt(u8 *raw_pkt, u8 *new_pkt, u32 tick_now);
int 	blt_llms_procScanData(u8 *raw_pkt);



/******************************* Stack Interface End *******************************************************************/








/******************************* User Interface  Begin *****************************************************************/
void 		blc_llms_initScanning_module(void);

ble_sts_t 	blc_llms_setScanParameter (scan_type_t scan_type, u16 scan_interval, u16 scan_window, own_addr_type_t  ownAddrType, scan_fp_type_t scanFilter_policy);
ble_sts_t 	blc_llms_setScanEnable (scan_en_t scan_enable, dupFilter_en_t filter_duplicate);


/******************************* User Interface  End  ******************************************************************/



#endif /* LLMS_SCAN_H_ */
