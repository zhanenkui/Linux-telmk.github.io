/********************************************************************************************************
 * @file     llms_master.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_MASTER_H_
#define LLMS_MASTER_H_


/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/
/*********************************************************************************
 *   17		  19	  23	 29		  31	 37		 39       41
 * 21.25	23.75	28.75	36.25	38.75	46.25	48.75    51.25
 *					  X				  				 X
 *					  		 V				 V				  V
 *
 *					 23		 29		 31		 37			  	  41
 *
 *					     25
 *					   31.25 mS
 ********************************************************************************/
#define 		MASTER_CONN_INTER_23							23
#define 		MASTER_CONN_INTER_25							25	// 31.25 mS
#define 		MASTER_CONN_INTER_29							29
#define 		MASTER_CONN_INTER_31							31
#define 		MASTER_CONN_INTER_37							37
#define 		MASTER_CONN_INTER_41							41


/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/








/******************************* Macro & Enumeration variables for User Begin ******************************************/



/******************************* Macro & Enumeration variables for User End ********************************************/









/******************************* Stack Interface Begin, user can not use!!! ********************************************/
int 	blms_m_connect (rf_packet_connect_t * pInit, u8 *raw_pkt);
int 	blms_btx_start (void);
int 	blms_btx_post (void);




/******************************* Stack Interface End *******************************************************************/




/******************************* User Interface  Begin *****************************************************************/
ble_sts_t	blc_llms_setMasterConnectionInterval(u16 conn_interval);   //This API master called after "blc_llms_setMaxConnectionNumber"



/******************************* User Interface  End  ******************************************************************/


#endif /* LLMS_MASTER_H_ */
