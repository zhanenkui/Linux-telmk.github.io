/********************************************************************************************************
 * @file     llms_adv.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/
#ifndef LLMS_ADV_H_
#define LLMS_ADV_H_

#include "stack/ble/ble_common.h"
#include "stack/ble/ble_format.h"

#include "stack/ble/whitelist/whitelist.h"
#include "llms_device.h"


/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/
_attribute_aligned_(4)
typedef struct {
	u8		adv_chn_mask;
	u8		adv_duraton_en;
	u8		adv_type;
	u8 		adv_filterPolicy;


	u16		advInt_min;
	u16 	advInt_max;

	u32		adv_duration_us;
	u32		adv_begin_tick;

	u8		T_SCAN_RSP_INTVL;
	u8      own_addr_type;


}st_llms_adv_t;



extern _attribute_aligned_(4) st_llms_adv_t  blmsAdv;


/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/








/******************************* Macro & Enumeration variables for User Begin ******************************************/
typedef enum {
	RAND_DLY_NONE		= 0,
	RAND_DLY_MAX_2MS5   = 0,  //random delay max: 2.5 mS
	RAND_DLY_MAX_5MS    = 0,  //random delay max: 5 mS
	RAND_DLY_MAX_10MS   = 0,  //random delay max: 10 mS
}max_rand_dly_t;


/******************************* Macro & Enumeration variables for User End ********************************************/





/******************************* Stack Interface Begin, user can not use!!! ********************************************/
int 	blt_llms_send_adv(void);
/******************************* Stack Interface End *******************************************************************/







/******************************* User Interface  Begin *****************************************************************/
void 		blc_llms_initAdvertising_module(void);

ble_sts_t  	blc_llms_setAdvData(u8 *data, u8 len);
ble_sts_t 	blc_llms_setScanRspData(u8 *data, u8 len);

ble_sts_t   blc_llms_setAdvParam( u16 intervalMin,  u16 intervalMax,  adv_type_t 	advType,  		  own_addr_type_t ownAddrType,  \
							      u8 peerAddrType, u8  *peerAddr,     adv_chn_map_t adv_channelMap,   adv_fp_type_t   advFilterPolicy);
ble_sts_t   blc_llms_setAdvEnable(adv_en_t adv_enable);


void 		blc_llms_setAdvCustomedChannel (u8 chn0, u8 chn1, u8 chn2);

/******************************* User Interface  End  ******************************************************************/





















#if (BLMS_MULTI_LOCAL_MAC_EN)
enum{
	MAC_INVALID,
	MAC_VALID,
};

enum{
	MAC_DISCONN,
	MAC_CONN,
};

typedef enum{
	ADV_OneMAC_TillConn,
	ADV_MAC_alternate,
}adv_mode_t;

_attribute_aligned_(4)
typedef struct{
	u8 mac_validFlg[SLAVE_MAX_NUM]; ///3
	u8 adv_mode;

	u8 mac_connFlg[SLAVE_MAX_NUM]; ///3
	u8 mac_cnt;

	u8 slaveMAC[SLAVE_MAX_NUM][BLE_ADDR_LEN]; ////3*6
	u8 rsvd0;
	u8 rsvd1;

}slave_macInfo_t;

/////variable declaration ////
extern u8 mode0_advIdx;
extern u8 mode1_advIdx;
extern _attribute_aligned_(4) slave_macInfo_t slave_macInfo;
extern u8 master_role_mac[];

////function declaration ////
/******************************************
 *brief: if the MAC address of master and slave,
 *the function is used to set the MAC address of master.
 */
void blc_llms_cfgMasterMAC(u8* mMac);
/*************************************************
 *brief: now provide two modes:
 * 1. always advertise using one MAC address till connection.
 * 2. alternate MAC address to advertise.
 */
void blc_llms_setSlaveAdvMode(adv_mode_t advMode);

/****************************************************
 *if only one MAC address and the MAC address may be changed according to time/GPIO or other action.
 *user can use the function to change the MAC.
 */
void blc_llms_cfgSlaveSingleMAC(u8* smac);

/**********************************
 * brief: the function can set the slave MAC address when slave is multiple address.
 * smac0 will always advertise firstly.so there is priority requirement,
 * please set smac0/smac1/smac2 in order.
 */
void blc_llms_cfgSlaveMultiMAC(u8* smac0, u8* smac1, u8* smac2);
/****************************************************************
 *brief: if the MAC address has been connection state,
 *but still need the mac to advertise and the previous connection
 *is not affected.
 */
int blc_llms_setMACConnSta_Disconn(u8* mac);

/********************************************************************
 *when advertise, find the relevant MAC address to advertise.
 */
void blc_llms_MulMac_AdvProc(void);

#endif



#endif /* LLMS_ADV_H_ */
