#define   BUILD_VERSION  	"Revision: 45:49M"
#define   BUILD_TIME  		"2012-07-24-21:37:43"
