
#pragma once

void audhw_set_pre_gain(int gain_left, int gain_right);
void audhw_set_post_gain(int gain_left, int gain_right);

