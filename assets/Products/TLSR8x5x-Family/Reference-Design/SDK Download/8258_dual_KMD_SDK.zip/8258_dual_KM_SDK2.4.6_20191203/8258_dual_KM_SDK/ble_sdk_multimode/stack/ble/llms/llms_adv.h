/*
 * llms_adv.h
 *
 *  Created on: 2019-5-25
 *      Author: Administrator
 */

#ifndef LLMS_ADV_H_
#define LLMS_ADV_H_













/************************************ User Interface  ******************************************************/
void 	blc_llms_initAdvertising_module(void);;







/*********************************** Stack Interface, user can not use!!! **********************************/
int 	blt_llms_send_adv(void);









#endif /* LLMS_ADV_H_ */
