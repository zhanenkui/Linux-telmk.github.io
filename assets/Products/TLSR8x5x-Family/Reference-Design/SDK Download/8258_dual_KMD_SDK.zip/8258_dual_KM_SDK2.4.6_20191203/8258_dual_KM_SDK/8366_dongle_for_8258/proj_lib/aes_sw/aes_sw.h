#ifndef _AES_H_
#define _AES_H_
  
typedef unsigned char           word8;	
typedef unsigned short          word16;	
typedef unsigned long           word32;




void _rijndaelSetKey (unsigned char *k);
void _rijndaelEncrypt(unsigned char *a);
void _rijndaelDecrypt (unsigned char *a);

#endif
