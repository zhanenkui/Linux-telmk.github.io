
#pragma once

/* Enable C linkage for C++ Compilers: */
#if defined(__cplusplus)
extern "C" {
#endif

void syshw_init();

/* Disable C linkage for C++ Compilers: */
#if defined(__cplusplus)
}
#endif

