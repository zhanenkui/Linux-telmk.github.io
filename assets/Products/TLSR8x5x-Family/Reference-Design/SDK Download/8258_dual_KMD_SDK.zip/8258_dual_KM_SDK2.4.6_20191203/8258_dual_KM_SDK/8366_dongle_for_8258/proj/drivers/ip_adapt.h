
#pragma once

void ipa_set_my_mac(u8 *mac);
void ipa_set_my_ip(u8 *ip);
void ipa_set_gateway(u8 *ip);
void ipa_set_netmask(u8 *ip);

