
#pragma once

void selection_sort_char(unsigned char * arr, int size);
void selection_sort_int(unsigned int * arr, int size);

