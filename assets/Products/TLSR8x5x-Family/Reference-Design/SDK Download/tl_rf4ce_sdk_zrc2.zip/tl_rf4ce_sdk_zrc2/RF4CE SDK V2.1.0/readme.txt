GitServer��
ssh://gitolite@192.168.48.47:222/zigbee  branch: telink_zigbee
SHA-1: a21ca21bb33a2ac9b6c7fbba38cd7080db718d77


Running on:
1) 8258 RC / Dongle board;
2) 8269 RC / Dongle board.

��2019-10-11��
Update infomation(VERSION:V2.0.0):
1)Add 8258 chip platform
2)Change OTA/Audio data processing process
  OTA/Audio is sent through zrc2.0
	
��2019-12-30��
Update infomation(VERSION:V2.1.0):
1)Auto-generated ota file in the proj
2)fix mac address issue
3)fix quick set IR toggle bit issue
4)add rsp code in the callback function for pushing attribute response
5)add callback for all of the command, optimize the discovery procedure
6)change led action for pair, audio issue for 8258
7)sdk issue; add demo for rf4ce/ble switch
8)update for rf4ce/ble dual mode switch
	
	
	
	
	
	
	