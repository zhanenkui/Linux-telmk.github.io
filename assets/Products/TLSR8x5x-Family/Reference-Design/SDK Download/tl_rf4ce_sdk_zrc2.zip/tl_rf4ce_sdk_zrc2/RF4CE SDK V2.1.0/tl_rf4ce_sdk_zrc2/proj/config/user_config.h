#pragma once

#include "../../vendor/common/user_config.h"

