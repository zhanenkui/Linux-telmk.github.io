
#pragma once

void reg_simu_init();

