After you get the sdk ,there are some steps for you to do.
1. 	you can not compile success,becase there is lib named"libmijia_std_authen_eclipse_telink_1_1_4.a"should provide by xiaomi ,
		so you need to contact xiaomi and get the lib ,and then put the lib to the path of the proj_lib.
2. 	this protocol can only be used to do the remote .


