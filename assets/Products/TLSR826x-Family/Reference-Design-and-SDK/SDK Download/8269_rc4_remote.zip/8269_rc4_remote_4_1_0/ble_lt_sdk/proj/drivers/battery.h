
#pragma once



void battery_power_check(void);
