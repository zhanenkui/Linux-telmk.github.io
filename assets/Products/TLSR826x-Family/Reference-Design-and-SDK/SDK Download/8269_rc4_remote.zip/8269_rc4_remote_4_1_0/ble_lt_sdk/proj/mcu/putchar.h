
#pragma once

#ifndef WIN32

int putchar(int c);

#endif


