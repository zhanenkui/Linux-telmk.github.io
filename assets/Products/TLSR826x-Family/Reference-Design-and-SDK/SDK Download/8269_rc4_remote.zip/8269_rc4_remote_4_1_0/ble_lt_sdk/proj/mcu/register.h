#pragma once
#include "../config/user_config.h"

#if(__TL_LIB_8266__ || MCU_CORE_TYPE == MCU_CORE_8266)
#include "../mcu_spec/register_8266.h"
#elif(__TL_LIB_8267__ || MCU_CORE_TYPE == MCU_CORE_8267 || \
	  __TL_LIB_8261__ || MCU_CORE_TYPE == MCU_CORE_8261 || \
	  __TL_LIB_8269__ || MCU_CORE_TYPE == MCU_CORE_8269 )
#include "../mcu_spec/register_8267.h"
#elif(__TL_LIB_5316__ || MCU_CORE_TYPE == MCU_CORE_5316)
#include "../mcu_spec/register_5316.h"
#else
#endif

