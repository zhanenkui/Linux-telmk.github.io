
#pragma once

void eth_simu_init(void);

