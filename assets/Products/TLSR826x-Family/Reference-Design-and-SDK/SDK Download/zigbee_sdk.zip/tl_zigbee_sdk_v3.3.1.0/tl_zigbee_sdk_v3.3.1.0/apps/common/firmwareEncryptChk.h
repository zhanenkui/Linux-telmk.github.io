#ifndef _FIRMWARE_ENCRYPT_CHECK_H_
#define _FIRMWARE_ENCRYPT_CHECK_H_

u8 firmwareCheckWithUID(void);

#endif	/* _FIRMWARE_ENCRYPT_CHECK_H_ */
