
#pragma once

extern s8 mouse_simu_x;
extern s8 mouse_simu_y;
extern s32 mouse_simu_wheel_value;
extern u8 mouse_simu_btn;

void mouse_simu_init(void);

