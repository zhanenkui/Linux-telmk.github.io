
#pragma once

void rf_simu_init(void);


