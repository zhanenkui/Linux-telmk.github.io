
#pragma once
#ifdef WIN32
#include <stdio.h>
#else
int my_printf_uart(const char *format,...);
int my_printf_uart_hexdump(char *p_buf,int len );
#define printf	my_printf_uart
#define sprintf	my_printf_uart_hexdump

#endif
