
#pragma once

void swire_set_clock(int div);

